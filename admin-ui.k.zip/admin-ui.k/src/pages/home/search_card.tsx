import { rst } from 'rt-state';
import React from 'react';
import { Grid, Paper, Typography } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import Container from '@material-ui/core/Container';
import { Field, Form, Formik } from 'formik';
import { array, date, mixed, object, string } from 'yup';
import { FAutocomplete } from '../../components/form/Autocomplete';
import { FSelect } from '../../components/form/Select';
import { FKeyboardTimePicker } from '../../components/form/KeyboardTimePicker';
import { FTextField } from '../../components/form/TextField';
import { FKeyboardDateTimePicker } from '../../components/form/KeyboardDateTimePicker';
import Hidden from '@material-ui/core/Hidden';
import { clsx } from '../../commons';

const validationSchema = object().shape({
    username: string().required('Username is required'),
    gender: string().required('Gender selection is required'),
    country: string().nullable().required('Country is required'),
    skills: array().required('At least one skill is required'),
    birthdate: date().nullable().required('Birth date is required'),
    interviewTime: mixed().required('Interview Time is required'),
});

const countries = [
    {
        label: 'Afghanistan',
        value: 'AF',
    },
    {
        label: 'Åland Islands',
        value: 'AX',
    },
    {
        label: 'Albania',
        value: 'AL',
    },
    {
        label: 'Algeria',
        value: 'DZ',
    },
    {
        label: 'American Samoa',
        value: 'AS',
    },
    {
        label: 'Andorra',
        value: 'AD',
    },
    {
        label: 'Angola',
        value: 'AO',
    },
    {
        label: 'Anguilla',
        value: 'AI',
    },
    {
        label: 'Antarctica',
        value: 'AQ',
    },
    {
        label: 'Antigua and Barbuda',
        value: 'AG',
    },
    {
        label: 'Argentina',
        value: 'AR',
    },
    {
        label: 'Armenia',
        value: 'AM',
    },
    {
        label: 'Aruba',
        value: 'AW',
    },
    {
        label: 'Australia',
        value: 'AU',
    },
    {
        label: 'Austria',
        value: 'AT',
    },
    {
        label: 'Azerbaijan',
        value: 'AZ',
    },
    {
        label: 'Bahamas',
        value: 'BS',
    },
    {
        label: 'Bahrain',
        value: 'BH',
    },
    {
        label: 'Bangladesh',
        value: 'BD',
    },
    {
        label: 'Barbados',
        value: 'BB',
    },
    {
        label: 'Belarus',
        value: 'BY',
    },
    {
        label: 'Belgium',
        value: 'BE',
    },
    {
        label: 'Belize',
        value: 'BZ',
    },
    {
        label: 'Benin',
        value: 'BJ',
    },
    {
        label: 'Bermuda',
        value: 'BM',
    },
    {
        label: 'Bhutan',
        value: 'BT',
    },
    {
        label: 'Bolivia',
        value: 'BO',
    },
    {
        label: 'Bosnia and Herzegovina',
        value: 'BA',
    },
    {
        label: 'Botswana',
        value: 'BW',
    },
    {
        label: 'Bouvet Island',
        value: 'BV',
    },
    {
        label: 'Brazil',
        value: 'BR',
    },
    {
        label: 'British Indian Ocean Territory',
        value: 'IO',
    },
    {
        label: 'Brunei Darussalam',
        value: 'BN',
    },
    {
        label: 'Bulgaria',
        value: 'BG',
    },
    {
        label: 'Burkina Faso',
        value: 'BF',
    },
    {
        label: 'Burundi',
        value: 'BI',
    },
];
const skills = [
    {
        label: 'Acceptance Testing',
        value: 'Acceptance Testing',
    },
    {
        label: 'ASP.NET',
        value: 'ASP.NET',
    },
    {
        label: 'Automated Testing',
        value: 'Automated Testing',
    },
    {
        label: 'C#',
        value: 'C#',
    },
    {
        label: 'C',
        value: 'C',
    },
    {
        label: 'C++',
        value: 'C++',
    },
    {
        label: 'CSS3',
        value: 'CSS3',
    },
    {
        label: 'Docker',
        value: 'Docker',
    },
    {
        label: 'ES6',
        value: 'ES6',
    },
    {
        label: 'HTML5',
        value: 'HTML5',
    },
    {
        label: 'Java',
        value: 'Java',
    },
    {
        label: 'Javascript',
        value: 'Javascript',
    },
    {
        label: 'MongoDB',
        value: 'MongoDB',
    },
    {
        label: 'MySQL',
        value: 'MySQL',
    },
    {
        label: 'PostgreSQL',
        value: 'PostgreSQL',
    },
    {
        label: 'Python',
        value: 'Python',
    },
    {
        label: 'React',
        value: 'React',
    },
    {
        label: 'Redis',
        value: 'Redis',
    },
    {
        label: 'Swift',
        value: 'Swift',
    },
    {
        label: 'Webpack',
        value: 'Webpack',
    },
];

const initialValues = {
    username: '',
    gender: 'Female',
    country: null,
    skills: [
        {
            label: 'ASP.NET',
            value: 'ASP.NET',
        },
    ],
    birthdate: null,
    interviewTime: null,
};

const onSubmit = (values) => {
    // eslint-disable-next-line no-alert
    window.alert(`
          Username: ${values.username}
          Gender: ${values.gender}
          Country: ${values.country.label}
          Skills: ${values.skills.map((v) => v.label).join(', ')}
          Birth date: ${values.birthdate}
          Interview Time: ${values.interviewTime}
        `);
};

export const FormSearchCard = rst.create<{}>((ctx) => {
    return (props) => {
        const node = (
            <Paper className={clsx('px-1', 'py-1')}>
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    validateOnBlur={false}
                    validateOnChange
                    onSubmit={onSubmit}>
                    {(formik) => (
                        <Form noValidate autoComplete="off">
                            <Grid direction={'column'} container>
                                <Grid item container>
                                    <Typography component={'div'} variant={'h6'}>
                                        <span>Search</span>
                                    </Typography>
                                    <Grid item xs />
                                    <Button
                                        variant={'contained'}
                                        onClick={(e) => {
                                            formik.resetForm();
                                        }}>
                                        Reset
                                    </Button>
                                    <Box pl={2} />
                                    <Button
                                        variant={'contained'}
                                        color={'primary'}
                                        type="submit"
                                        disabled={!formik.dirty}>
                                        Confirm
                                    </Button>
                                </Grid>
                                <Grid item>
                                    <Grid container spacing={1}>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                required
                                                name="username"
                                                label="Username"
                                                component={FTextField}
                                                size="small"
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                required
                                                name="gender"
                                                label="Gender"
                                                options={[
                                                    { value: '', label: '-- No selection --' },
                                                    { value: 'Male', label: 'Male' },
                                                    { value: 'Female', label: 'Female' },
                                                    { value: 'Other', label: 'Other' },
                                                ]}
                                                component={FSelect}
                                                size="small"
                                                variant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="country"
                                                options={countries}
                                                component={FAutocomplete}
                                                size="small"
                                                textFieldProps={{
                                                    label: 'Country',
                                                    required: true,
                                                    variant: 'outlined',
                                                }}
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="skills"
                                                options={skills}
                                                component={FAutocomplete}
                                                size="small"
                                                textFieldProps={{
                                                    label: 'Skills',
                                                    required: true,
                                                    variant: 'outlined',
                                                }}
                                                multiple
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                required
                                                name="birthdate"
                                                component={FKeyboardDateTimePicker}
                                                label="Birth date"
                                                format="dd/MM/yyyy hh:mm"
                                                size="small"
                                                inputVariant="outlined"
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                required
                                                name="interviewTime"
                                                component={FKeyboardTimePicker}
                                                label="Interview Time"
                                                size="small"
                                                inputVariant="outlined"
                                                mask="__:__"
                                                ampm={false}
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Paper>
        );

        return (
            <Hidden xsDown implementation={'css'}>
                {node}
            </Hidden>
        );
    };
});

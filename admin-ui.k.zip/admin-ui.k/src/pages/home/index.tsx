import { rst } from 'rt-state';
import React from 'react';
import { Container } from '@material-ui/core';
import Box from '@material-ui/core/Box';
import { FormSearchCard } from './search_card';
import { ActionOverriding } from './table';
import { clsx } from '../../commons';

export const HomePage = rst.createS<{}>((props) => {
    return (
        <Container className={clsx('px-1', 'py-1')}>
            <FormSearchCard />
            <Box pt={2} />
            <ActionOverriding />
        </Container>
    );
});

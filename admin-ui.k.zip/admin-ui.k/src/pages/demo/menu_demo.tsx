import React from 'react';
import AddIcon from '@material-ui/icons/Add';
import IconButton from '@material-ui/core/IconButton';
import CascadingMenu from '../../components/cascading_menu/cascading_menu';
import { Box } from '@material-ui/core';
import { rst } from 'rt-state';

const menuItems = [
    {
        key: '1',
        caption: 'Button 1',
        onClick: () => {},
    },
    {
        key: '2',
        caption: 'Button 2',
        onClick: () => {},
    },
    {
        key: '3',
        caption: 'Button 3',
        onClick: () => {},
    },
    {
        key: 'group-1',
        caption: 'Group 1',
        subMenuItems: [
            {
                key: '4',
                caption: 'Button 4',
                onClick: () => {},
            },
            {
                key: '5',
                caption: 'Button 5',
                onClick: () => {},
            },
            {
                key: '6',
                caption: 'Button 6',
                onClick: () => {},
            },
        ],
    },
    {
        key: 'group-2',
        caption: 'Group 2',
        subMenuItems: [
            {
                key: '7',
                caption: 'Button 7',
                onClick: () => {},
            },
            {
                key: '8',
                caption: 'Button 8',
                onClick: () => {},
            },
            {
                key: '9',
                caption: 'Button 9',
                onClick: () => {},
            },
        ],
    },
];

const CascadingMenuDemo = rst.create(() => {
    const state = rst.stateS({
        anchorElement: null,
    });
    const handleClick = (event) => {
        rst.setStateS(state, { anchorElement: event.currentTarget });
    };

    const handleClose = () => {
        rst.setStateS(state, { anchorElement: null });
    };

    return () => {
        const { anchorElement } = state;

        return (
            <div style={{ margin: 'auto', width: 300 }}>
                <Box pt={30} />
                <IconButton onClick={handleClick}>
                    <AddIcon />
                </IconButton>
                <CascadingMenu
                    anchorElement={anchorElement}
                    // anchorOrigin={{
                    //     vertical: 'bottom',
                    //     horizontal: 'left',
                    // }}
                    menuItems={menuItems}
                    onClose={handleClose}
                    open={Boolean(anchorElement)}
                    transformOrigin={{
                        vertical: 'bottom',
                        horizontal: 'left',
                    }}
                />
            </div>
        );
    };
});

export default CascadingMenuDemo;

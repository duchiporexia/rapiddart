const { createProxyMiddleware } = require('http-proxy-middleware');
const Bundler = require('parcel-bundler');
const express = require('express');

const app = express();

app.use(
    '/api',
    createProxyMiddleware({
        changeOrigin: true,
        secure: false,
        target: '...',
    }),
);
const bundler = new Bundler('./src/index.html', { cache: false });

app.use(bundler.middleware());
const PORT = 1234;
console.log(`server is running at http://localhost:${PORT}`);
app.listen(PORT);

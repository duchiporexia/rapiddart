import * as jwtDecode from 'jwt-decode';

export interface TokenInfo {
    token?: string;
    valid?: boolean;
    username?: string;
    displayName?: string;
    roles?: string[];

    iat?: number;
    exp?: number;
}

export const decodeToken = (token: string): TokenInfo => {
    try {
        const jwtObject = jwtDecode.default(token);
        const tokenInfo = {
            token,
            valid: true,
            username: jwtObject.sub,
            displayName: jwtObject.displayName,
            roles: jwtObject.roles?.split(',') ?? [],

            iat: jwtObject.iat,
            exp: jwtObject.exp,
        };
        const expTime = new Date(jwtObject.exp * 1000);
        if (new Date() < expTime) {
            return tokenInfo;
        }
    } catch (e) {}

    return { token, valid: false };
};

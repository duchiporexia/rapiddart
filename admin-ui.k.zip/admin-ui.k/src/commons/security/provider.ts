import { storage } from '../storage';
import { injectToken } from '../axios';
import { rst } from 'rt-state';
import { getPermissionsByNamespace } from './authz';
import { TokenInfo, decodeToken } from './authn';

function createSecurityProvider() {
    const tokenInfo = rst.stateS<TokenInfo>({ token: '', valid: false });

    const applyToken = (token: string) => {
        const newTokenInfo = decodeToken(token);
        rst.setStateS(tokenInfo, newTokenInfo);
        injectToken(token);
    };

    const loading = rst.stateV(true);

    const setToken = async (token: string) => {
        applyToken(token);
        await storage.save('token', token);
    };

    const isLoading = () => {
        return loading.value;
    };

    const getPermissions = (namespace: string) => (resource: string) => {
        return getPermissionsByNamespace(tokenInfo.roles, namespace, resource);
    };

    storage.get('token').then((token: string) => {
        applyToken(token);
        loading.value = false;
    });

    return { tokenInfo, setToken, isLoading, getPermissions };
}

export const SecurityProvider = rst.createProvider(createSecurityProvider);

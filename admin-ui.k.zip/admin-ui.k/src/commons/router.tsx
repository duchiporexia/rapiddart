import * as React from 'react';
import { Link as RouterLink, LinkProps as RouterLinkProps } from 'react-router-dom';

export const RRLink = React.forwardRef<HTMLAnchorElement, RouterLinkProps>((props, ref) => (
    <RouterLink innerRef={ref} {...props} />
));

export const getParamsFromLocation = (loc: any) => {
    let path = loc?.search;
    if (path == null) {
        return {};
    }
    if (path.startsWith('?')) {
        path = path.substr(1);
    }
    const kvs = path.split('&');
    const ret = {} as any;
    for (const kv of kvs) {
        const v = kv.split('=');
        if (v.length === 2) {
            ret[v[0]] = ret[v[1]];
        }
    }
    return ret;
};

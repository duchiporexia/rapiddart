import React from 'react';

import AccountBoxIcon from '@material-ui/icons/AccountBox';
import AppBar from '@material-ui/core/AppBar';
import Badge from '@material-ui/core/Badge';
import Collapse from '@material-ui/core/Collapse';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import FullscreenIcon from '@material-ui/icons/Fullscreen';
import Hidden from '@material-ui/core/Hidden';
import IconButton from '@material-ui/core/IconButton';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Menu from '@material-ui/core/Menu';
import MenuIcon from '@material-ui/icons/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import NotificationsIcon from '@material-ui/icons/Notifications';
import NotificationsOffIcon from '@material-ui/icons/NotificationsOff';
import SearchIcon from '@material-ui/icons/Search';
import Toolbar from '@material-ui/core/Toolbar';
import classNames from 'classnames';
import { useStyles } from './styles';
import { rst } from 'rt-state';
import { AppProvider } from '../app_provider';
import BrightIcon from '@material-ui/icons/Brightness1';

export const Header = rst.create<{
    logo: string;
    logoAltText: string;
    toggleFullscreen: any;
    toggleDrawer: any;
    toogleNotifications: any;
}>((ctx) => {
    const appProvider = AppProvider.use();
    const anchorElState = rst.stateV(null);
    const searchExpanded = rst.stateV(false);
    const handleSettingsToggle = (event) => {
        anchorElState.value = event.currentTarget;
    };

    const handleThemeModeToggle = () => {
        appProvider.toggleThemeMode();
        anchorElState.value = null;
    };

    const handleCloseMenu = () => {
        anchorElState.value = null;
    };

    const handleSearchExpandToggle = () => {
        searchExpanded.value = !searchExpanded.value;
    };

    const handleDrawerToggle = () => {
        ctx.props.toggleDrawer();
        if (searchExpanded.value) {
            handleSearchExpandToggle();
        }
    };

    const handleNotificationToggle = () => {
        ctx.props.toogleNotifications();
        if (searchExpanded.value) {
            handleSearchExpandToggle();
        }
    };

    return (props) => {
        const classes = useStyles();
        return (
            <AppBar position="static" className={classes.appBar}>
                <Toolbar className={classes.toolBar}>
                    <IconButton color="inherit" aria-label="open drawer" onClick={handleDrawerToggle}>
                        <MenuIcon />
                    </IconButton>

                    <div className={classes.branding}>
                        <img src={props.logo} alt={props.logoAltText} className={classes.logo} />
                    </div>

                    <Hidden xsDown>
                        <div className={classes.searchWrapper} />
                    </Hidden>

                    <Hidden smUp>
                        <span className="flexSpacer" />
                    </Hidden>

                    <Hidden xsDown>
                        <IconButton color="inherit" onClick={props.toggleFullscreen}>
                            <FullscreenIcon />
                        </IconButton>
                    </Hidden>

                    <IconButton color="inherit" onClick={handleNotificationToggle}>
                        <Badge badgeContent={5} color="secondary">
                            <NotificationsIcon />
                        </Badge>
                    </IconButton>

                    <IconButton
                        aria-label="User Settings"
                        aria-owns={anchorElState.value ? 'user-menu' : null}
                        aria-haspopup="true"
                        color="inherit"
                        onClick={handleSettingsToggle}>
                        <MoreVertIcon />
                    </IconButton>

                    <Menu
                        id="user-menu"
                        anchorEl={anchorElState.value}
                        open={Boolean(anchorElState.value)}
                        onClose={handleCloseMenu}>
                        <MenuItem onClick={handleThemeModeToggle}>
                            <ListItemIcon>
                                <BrightIcon />
                            </ListItemIcon>
                            <ListItemText primary={`Theme ${appProvider.getNextThemeMode()}`} />
                        </MenuItem>
                        <MenuItem onClick={handleCloseMenu}>
                            <ListItemIcon>
                                <AccountBoxIcon />
                            </ListItemIcon>
                            <ListItemText primary="Profile" />
                        </MenuItem>
                        <MenuItem onClick={handleCloseMenu}>
                            <ListItemIcon>
                                <NotificationsOffIcon />
                            </ListItemIcon>
                            <ListItemText primary="Disable notifications" />
                        </MenuItem>
                        <MenuItem onClick={handleCloseMenu}>
                            <ListItemIcon>
                                <ExitToAppIcon />
                            </ListItemIcon>
                            <ListItemText primary="Sign out" />
                        </MenuItem>
                    </Menu>
                </Toolbar>
                <Hidden smUp>
                    <Collapse in={searchExpanded.value} timeout="auto" unmountOnExit>
                        <Toolbar className={classes.toolBar}>
                            <div className={classes.searchWrapper}>
                                <form className={classNames(classes.searchForm, 'mr-0')}>
                                    <IconButton aria-label="Search" className={classes.searchIcon}>
                                        <SearchIcon />
                                    </IconButton>
                                    <input
                                        className={classes.searchInput}
                                        type="text"
                                        placeholder="Search"
                                        autoFocus={true}
                                    />
                                </form>
                            </div>
                        </Toolbar>
                    </Collapse>
                </Hidden>
            </AppBar>
        );
    };
});

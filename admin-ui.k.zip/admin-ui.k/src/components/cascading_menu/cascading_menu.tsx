import React from 'react';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import MenuList from '@material-ui/core/MenuList';
import Paper from '@material-ui/core/Paper';
import ArrowRightIcon from '@material-ui/icons/KeyboardArrowRight';
import { useStyles } from './cascading_menu.styles';
import { rst } from 'rt-state';
import { MenuProps } from '@material-ui/core/Menu/Menu';

interface CascadingMenuProps {
    anchorElement: any;
    menuItems: any[];
    onClose: () => void;
    open: boolean;
}

const CascadingMenu = rst.create<CascadingMenuProps & MenuProps>((ctx) => {
    const state = rst.stateS({
        subMenuStates: [],
    });

    const handleItemClick = (event, menuItem) => {
        event.preventDefault();
        event.stopPropagation();
        const hasSubMenu = !!(menuItem.subMenuItems && menuItem.subMenuItems.length);

        if (hasSubMenu) {
            // hide already open sub menus and open the requested sub menu
            const subMenuStates = [...state.subMenuStates];

            for (const subMenuState of subMenuStates) {
                if (subMenuState.key === menuItem.key) {
                    subMenuState.anchorElement = event.target;
                    subMenuState.open = !subMenuState.open;
                } else {
                    subMenuState.open = false;
                }
            }

            rst.setStateS(state, { subMenuStates });
        } else {
            closeAllMenus();
        }
        console.log(menuItem);

        menuItem.onClick?.();
    };

    const closeAllMenus = () => {
        rst.setStateS(state, { subMenuStates: [] });
        ctx.props.onClose();
    };

    const renderMenuItem = (menuItem: any, classes) => {
        const { subMenuStates } = state;
        const hasSubMenu = !!(menuItem.subMenuItems && menuItem.subMenuItems.length);
        let subMenuState = subMenuStates.find((menuState) => menuState.key === menuItem.key);

        // initialize state for sub menu
        if (hasSubMenu && !subMenuState) {
            subMenuState = {
                key: menuItem.key,
                anchorElement: null,
                open: false,
            };

            subMenuStates.push(subMenuState);
        }

        return (
            <MenuItem onClick={(e) => handleItemClick(e, menuItem)} className={classes.menuItem} key={menuItem.key}>
                <div className={classes.caption}>{menuItem.caption}</div>
                {hasSubMenu && (
                    <React.Fragment>
                        <ArrowRightIcon className={classes.arrowIcon} />
                        <Paper className={`${classes.subMenu} ${subMenuState.open ? classes.subMenuOpen : ''}`}>
                            <MenuList>
                                {menuItem.subMenuItems.map((subMenuItem) => renderMenuItem(subMenuItem, classes))}
                            </MenuList>
                        </Paper>
                    </React.Fragment>
                )}
            </MenuItem>
        );
    };

    return (props) => {
        const classes = useStyles();
        const { anchorElement, open, onClose, menuItems, ...others } = props;

        return (
            <Menu
                {...others}
                anchorEl={anchorElement}
                elevation={2}
                classes={{
                    paper: classes.rootMenu,
                }}
                open={open}
                onClose={() => closeAllMenus()}>
                {menuItems.map((menuItem) => renderMenuItem(menuItem, classes))}
            </Menu>
        );
    };
});

export default CascadingMenu;

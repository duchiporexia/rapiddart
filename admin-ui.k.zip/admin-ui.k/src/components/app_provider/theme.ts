import { ThemeOptions } from '@material-ui/core/styles/createMuiTheme';
import indigo from '@material-ui/core/colors/indigo';
import red from '@material-ui/core/colors/red';

export const themeOptions: ThemeOptions = {
    typography: {
        fontSize: 12,
        fontFamily: ['"Roboto"', 'Arial', 'sans-serif'].join(','),
        fontWeightLight: 300,
        fontWeightMedium: 500,
        fontWeightBold: 900,
    },
    direction: 'ltr',
    palette: {
        type: 'light',
        primary: indigo,
        secondary: red,
        error: red,
    },
    shape: {
        borderRadius: 4,
    },
    props: {},
};

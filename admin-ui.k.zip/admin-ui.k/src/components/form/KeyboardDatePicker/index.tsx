import React from 'react';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { KeyboardDatePicker } from '@material-ui/pickers';
import { rst } from 'rt-state';
import { pickerWrapper } from '../common';

export const FKeyboardDatePicker = rst.createS<FKeyboardDatePickerProps>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return pickerWrapper(
            <KeyboardDatePicker
                label={label}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onChange={(value) => setFieldValue(field.name, value)}
                value={field.value}
                {...other}
            />,
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            autoOk: true,
        } as any,
    },
);

export interface FKeyboardDatePickerProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    autoOk?: boolean;
}

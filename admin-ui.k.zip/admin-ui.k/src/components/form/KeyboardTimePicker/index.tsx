import React from 'react';
import { KeyboardTimePicker } from '@material-ui/pickers';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { pickerWrapper } from '../common';

export const FKeyboardTimePicker = rst.createS<FKeyboardTimePickerProps>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return pickerWrapper(
            <KeyboardTimePicker
                label={label}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onChange={(value) => setFieldValue(field.name, value)}
                value={field.value}
                {...other}
            />,
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            autoOk: true,
        } as any,
    },
);

export interface FKeyboardTimePickerProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    autoOk?: boolean;
}

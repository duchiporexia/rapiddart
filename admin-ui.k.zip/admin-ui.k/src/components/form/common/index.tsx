import DateFnsAdapter from '@date-io/date-fns';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import React from 'react';

export const pickerWrapper = (children: React.ReactNode) => {
    return <MuiPickersUtilsProvider utils={DateFnsAdapter}>{children}</MuiPickersUtilsProvider>;
};

import React from 'react';
import TextField, { TextFieldProps } from '@material-ui/core/TextField';
import Autocomplete, { AutocompleteProps } from '@material-ui/lab/Autocomplete';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { SelectOptionsType } from '../index';
import { rst } from 'rt-state';

export const FAutocomplete = rst.createS<FAutocompleteProps & AutocompleteProps<any, any, any, any>>(
    (props) => {
        const {
            field,
            form: { dirty, touched, errors, setFieldValue },
            options,
            getOptionLabel,
            textFieldProps,
            ...autoCompleteProps
        } = props;

        // Merge default textFieldProps with textFieldProps passed in the component
        const mergedTextFieldProps: TextFieldProps = {
            ...{
                required: false,
                fullWidth: true,
                margin: 'normal',
            },
            ...textFieldProps,
        };
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = dirty && touchedVal && errorText !== undefined;
        const isMultiple = autoCompleteProps.multiple;
        const isMultipleWithValue = isMultiple && field.value;
        const canBeRendered = !isMultiple || isMultipleWithValue;

        if (isMultiple && field.value === null) {
            console.error(`Initial value of autocomplete with name: "${field.name}" cannot be null. Use [] instead.`);
        }

        return (
            <>
                {canBeRendered && (
                    <Autocomplete
                        options={options}
                        getOptionLabel={getOptionLabel}
                        onChange={(_, value) => setFieldValue(field.name, value)}
                        value={field.value}
                        getOptionSelected={(option, val) => option.value === val.value}
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                error={hasError}
                                helperText={hasError ? errorText : ''}
                                {...mergedTextFieldProps}
                            />
                        )}
                        {...autoCompleteProps}
                    />
                )}
            </>
        );
    },
    {
        defaultProps: {
            getOptionLabel: (option) => option.label,
        } as any,
    },
);

export interface FAutocompleteProps {
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    options: Array<SelectOptionsType>;
    textFieldProps: {
        label?: string;
        required?: boolean;
        fullWidth?: boolean;
        margin?: 'none' | 'dense' | 'normal';
    };
}

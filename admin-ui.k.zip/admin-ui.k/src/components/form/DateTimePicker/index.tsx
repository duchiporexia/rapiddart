import React from 'react';
import { DateTimePicker } from '@material-ui/pickers';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { pickerWrapper } from '../common';

export const FDateTimePicker = rst.createS<FDateTimePickerProps>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return pickerWrapper(
            <DateTimePicker
                label={label}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onChange={(value) => setFieldValue(field.name, value)}
                value={field.value}
                {...other}
            />,
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            ampm: false,
            autoOk: true,
        } as any,
    },
);
export interface FDateTimePickerProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    ampm?: boolean;
    autoOk?: boolean;
}

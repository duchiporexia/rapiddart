# servicehubui

A new Flutter project.

## TODO
* get storage
* fluro
* form
* auth/jwt
* table


//////
* dio / msgp
* flutter_screenUtil
* i18n 
* getx utils
* styled_widget

export interface CommonResult<T> {
    code: number;
    message: string;
    data: T;
}

export interface CommonPage<T> {
    total: number;
    list: T[];
}

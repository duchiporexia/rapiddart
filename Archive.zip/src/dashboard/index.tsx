import * as React from 'react';
import { Route, Switch } from 'react-router-dom';
import { useStyles } from './dashboard.styles';
import { rst } from 'rt-state';
import { AppProvider } from '../components/app_provider';
import { Header } from '../components/header';
import { clsx, MobileBreakpoint } from '../commons';
import { Sidebar } from '../components/sidebar';
import { Workspace } from '../components/workspace';
import { routes } from '../routes';

export const Dashboard = rst.create<{ history: any }>((ctx) => {
    const appProvider = AppProvider.use();
    const openedV = rst.stateV(true);
    const notificationsOpenV = rst.stateV(false);
    const openSpeedDialV = rst.stateV(false);

    const mediaMatcher = matchMedia(`(max-width: ${MobileBreakpoint}px)`);

    const resizeDispatch = () => {
        if (typeof Event === 'function') {
            window.dispatchEvent(new Event('resize'));
        } else {
            const evt = window.document.createEvent('UIEvents') as any;
            evt.initUIEvent('resize', true, false, window, 0);
            window.dispatchEvent(evt);
        }
    };

    const handleDrawerToggle = () => {
        openedV.value = !openedV.value;
        resizeDispatch();
    };

    const handleNotificationToggle = () => {
        notificationsOpenV.value = !notificationsOpenV.value;
    };

    const handleFullscreenToggle = () => {
        const element = document.querySelector('#root') as any;
        const doc = document as any;
        const isFullscreen = doc.webkitIsFullScreen || doc.mozFullScreen || false;

        element.requestFullScreen =
            element.requestFullScreen ||
            element.webkitRequestFullScreen ||
            element.mozRequestFullScreen ||
            function () {
                return false;
            };
        doc.cancelFullScreen =
            doc.cancelFullScreen ||
            doc.webkitCancelFullScreen ||
            doc.mozCancelFullScreen ||
            function () {
                return false;
            };
        isFullscreen ? doc.cancelFullScreen() : element.requestFullScreen();
    };

    const handleSpeedDialOpen = () => {
        openSpeedDialV.value = true;
    };

    const handleSpeedDialClose = () => {
        openSpeedDialV.value = false;
    };

    const getRoutes = (
        <Switch>
            {routes.items.map((item, index) =>
                item.type === 'external' ? (
                    <Route exact path={item.path} component={item.component} name={item.name} key={index} />
                ) : item.type === 'submenu' ? (
                    item.children.map((subItem) => (
                        <Route
                            exact
                            path={`${item.path}${subItem.path}`}
                            component={subItem.component}
                            name={subItem.name}
                        />
                    ))
                ) : (
                    <Route exact path={item.path} component={item.component} name={item.name} key={index} />
                ),
            )}
            {/*<Redirect to="/404" />*/}
        </Switch>
    );

    const runOnce = () => {
        if (mediaMatcher.matches) {
            openedV.value = false;
        }
        mediaMatcher.addListener((match) => {
            setTimeout(() => {
                if (match.matches) {
                    openedV.value = false;
                } else {
                    openedV.value = true;
                }
            }, 300);
        });

        const unlisten = ctx.props.history.listen(() => {
            if (mediaMatcher.matches) {
                openedV.value = false;
            }
            const elm = document.querySelector('#root > div > main');
            if (elm) {
                elm.scrollTop = 0;
            }
        });

        return () => {
            unlisten();
            mediaMatcher.removeListener((match) => {
                setTimeout(() => {
                    if (match.matches) {
                        openedV.value = false;
                    } else {
                        openedV.value = true;
                    }
                }, 300);
            });
        };
    };

    const releaseCB = runOnce();

    ctx.onDispose(releaseCB);

    return (props) => {
        const classes = useStyles();
        // @ts-ignore
        const sidebar = <Sidebar routes={routes.items} opened={openedV.value} toggleDrawer={handleDrawerToggle} />;
        return (
            <>
                <Header
                    logoAltText="Primer Admin Template"
                    logo={`${process.env.PUBLIC_URL}/static/images/logo.svg`}
                    toggleDrawer={handleDrawerToggle}
                    toogleNotifications={handleNotificationToggle}
                    toggleFullscreen={handleFullscreenToggle}
                />
                <div className={clsx(classes.panel, 'theme-dark')}>
                    {sidebar}
                    <Workspace opened={openedV.value}>{getRoutes}</Workspace>
                </div>
            </>
        );
    };
});

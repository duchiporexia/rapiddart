export interface StateV<T> {
    value: T
}

export interface Context<T> {
    active: boolean;
    props: T;
    w(): T;
    onDispose(cb: ()=>void): void;
}

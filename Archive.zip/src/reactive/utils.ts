import * as React from 'react';
import { getEffect, unwatch, state, Effect, currEffect } from './reactive';
import { Context, StateV } from './model';

let currSysContext: SysContext<any>;

export function create<T>(setup: (ctx: Context<T>) => (props: T) => React.ReactNode): React.FC<T> {
    //////////////////////////////////////////////////
    let dom = React.memo((_props: T) => {
        const update = React.useReducer(s => s + 1, 0)[1];
        const sysCtxRef = React.useRef<SysContext<T>>({
            effect: null,
            cleanup: new Set<Function>(),
            props: _props,
            watchProps: state({v: _props}),
        });
        React.useEffect(() => {
            return () => {
                sysCtxRef.current.cleanup.forEach(c => c());
            }
        }, []);
        ////////////////////////////////////////////////
        sysCtxRef.current.props = _props;
        sysCtxRef.current.watchProps.v = _props;
        let effect = sysCtxRef.current.effect;
        if (!effect) {
            currSysContext = sysCtxRef.current;
            const ctx = new _Context(sysCtxRef.current);
            const render = setup(ctx);
            const getter = () => render(sysCtxRef.current.props);
            effect = getEffect(getter, () => update());
            sysCtxRef.current.cleanup.add(() => unwatch(effect));
            sysCtxRef.current.effect = effect;
        }
        return effect();
    });
    return dom as any;
}

export function watch(cb: (values, oldValues) => void|Promise<void>, deps?: () => any[]) {
    let oldValues = null;
    let update = () => {
        if (!effect.active) {
            return;
        }
        let newValues = effect();
        cb(newValues, oldValues);
        oldValues = newValues;
    };
    const getter = deps ?? (() => null);

    const effect = getEffect(getter, update);
    currSysContext.cleanup.add(() => unwatch(effect));

    const values = effect();
    cb(values, oldValues);
    oldValues = values;

    return effect;
}

export function stateF<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    let dirty = true;
    let value: T;

    const effect = getEffect(getter, () => (dirty = true));
    currSysContext.cleanup.add(() => unwatch(effect));

    return {
        effect,
        get value() {
            if (dirty) {
                value = effect();
                // because currEffect depends on this effect, so also depends on the deps of this effect
                resolveDeps(effect.deps);
                dirty = false;
            }
            return value;
        },
        set value(newValue: T) {
            if (effect.active && setter != null) {
                setter(newValue);
            }
        }
    } as any
}

function resolveDeps(deps: Set<Effect>[]) {
    deps.forEach(dep => {
        if (!dep.has(currEffect)) {
            dep.add(currEffect);
            currEffect.deps.push(dep);
        }
    });
}

class _Context<T> {
    _sysCtx: SysContext<T>;

    constructor(sysCtx: SysContext<T>) {
        this._sysCtx = sysCtx;
    }

    get active(): boolean {
        return this._sysCtx.effect.active ?? false;
    }
    get props(): T {
        return this._sysCtx.props;
    }
    w(): T {
        return this._sysCtx.watchProps.v;
    }
    onDispose(cb: () => void) {
        if (!this._sysCtx.cleanup.has(cb)) {
            this._sysCtx.cleanup.add(cb);
        }
    }
}


interface SysContext<T> {
    cleanup: Set<Function>;
    effect: Effect;
    props: T;
    watchProps: {v: T};
}


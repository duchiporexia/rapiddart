import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { rst } from 'rt-state';

const useStyles = makeStyles((theme) => ({
    root: {
        padding: theme.spacing(1),
    },
}));

const Wrapper = rst.createS<{
    children: any;
    padding: boolean;
}>(({ children, padding = true }) => {
    const classes = useStyles();
    return <div className={padding ? classes.root : null}>{children}</div>;
});

export default Wrapper;

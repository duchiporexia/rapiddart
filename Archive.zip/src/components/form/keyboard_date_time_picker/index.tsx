import React from 'react';
import { KeyboardDateTimePicker } from '@material-ui/pickers';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { pickerWrapper } from '../common';

export const FKeyboardDateTimePicker = rst.createS<FKeyboardDateTimePickerProps>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return pickerWrapper(
            <>
                <KeyboardDateTimePicker
                    label={label}
                    error={hasError}
                    helperText={hasError ? errorText : ''}
                    onChange={(value) => setFieldValue(field.name, value)}
                    value={field.value}
                    {...other}
                />
            </>,
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            size: 'small',
            autoOk: true,
            inputVariant: 'outlined',
        } as any,
    },
);

export interface FKeyboardDateTimePickerProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
    autoOk?: boolean;
    inputVariant?: 'outlined';
}

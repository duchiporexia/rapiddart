import React from 'react';
import Switch from '@material-ui/core/Switch';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { Theme, withTheme } from '@material-ui/core/styles';
import FormHelperText from '@material-ui/core/FormHelperText';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';

const FSwitch = rst.create<{
    theme?: Theme;
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    required?: boolean;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
}>(
    (ctx) => {
        const {
            form: { values },
            field: { name },
        } = ctx.props;
        const initialState = values[name];
        const state = rst.state({ isChecked: initialState });

        return (props) => {
            const {
                label,
                field,
                form: { touched, errors, values, setFieldValue },
                required,
                fullWidth,
                margin,
                size,
                theme,
                ...other
            } = props;
            const { isChecked } = state;

            const errorText = getIn(errors, field.name);
            const touchedVal = getIn(touched, field.name);
            const hasError = touchedVal && errorText !== undefined;
            const errorColor = theme.palette.error.main;
            const labelStyle = hasError ? { color: errorColor } : {};

            const controlProps = {
                checked: isChecked,
                value: values[field.name],
                size,
                onChange: (event) => {
                    const { checked } = event.target;
                    state.isChecked = checked;
                    setFieldValue(field.name, checked);
                },
            };

            return (
                <FormControl fullWidth={fullWidth} required={required} margin={margin} error={hasError} {...other}>
                    <FormControlLabel
                        control={<Switch {...controlProps} />}
                        label={<span style={labelStyle}>{label}</span>}
                    />
                    {hasError && <FormHelperText>{errorText}</FormHelperText>}
                </FormControl>
            );
        };
    },
    {
        defaultProps: {
            theme: {},
            required: false,
            fullWidth: true,
            margin: 'normal',
            size: 'small',
        } as any,
    },
);

export default withTheme(FSwitch);

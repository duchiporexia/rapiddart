import React from 'react';
import ChipInput, {
    FilledTextFieldProps,
    OutlinedTextFieldProps,
    StandardTextFieldProps,
} from 'material-ui-chip-input';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';

export const FChipInput = rst.create<FChipInputProps & ChipInputProps>(
    (ctx) => {
        const handleAddChip = (chip) => {
            const {
                form: { setFieldValue },
                field: { name, value },
            } = ctx.props;

            const newValue = [...value, chip];
            setFieldValue(name, newValue);
        };

        const handleDeleteChip = (chip, index) => {
            const {
                form: { setFieldValue },
                field: { name, value },
            } = ctx.props;

            const newValue = value.filter((val, idx) => idx !== index);
            setFieldValue(name, newValue);
        };
        return (props) => {
            const {
                required,
                form: { dirty, touched, errors },
                field: { name, value },
                fullWidth,
                margin,
                size,
                ...other
            } = props;

            const id = `chip_${name}`;
            const errorText = getIn(errors, name);
            const touchedVal = getIn(touched, name);
            const hasError = dirty && touchedVal && errorText !== undefined;

            return (
                <ChipInput
                    required={required}
                    value={value}
                    InputProps={{
                        name,
                        id: `input_${id}`,
                    }}
                    onAdd={handleAddChip}
                    onDelete={handleDeleteChip}
                    helperText={hasError ? errorText : ''}
                    error={hasError}
                    margin={margin}
                    fullWidth={fullWidth}
                    size={size}
                    {...other}
                />
            );
        };
    },
    {
        defaultProps: {
            label: '',
            fullWidth: true,
            margin: 'normal',
            size: 'small',
            // http://gcctech.org/csc/javascript/javascript_keycodes.htm
            // Enter, Space, Comma
            newChipKeyCodes: [13, 32, 188],
        } as any,
    },
);

export interface FChipInputProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
    newChipKeyCodes?: number;
}
export type ChipInputProps = StandardTextFieldProps | FilledTextFieldProps | OutlinedTextFieldProps;

import React from 'react';
import { TimePicker } from '@material-ui/pickers';
import { FieldProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { FieldInputProps } from 'formik/dist/types';

export const FTimePicker = rst.createS<{
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
    inputVariant?: 'outlined';
    autoOk?: boolean;
}>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return (
            <TimePicker
                label={label}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onChange={(value) => setFieldValue(field.name, value)}
                value={field.value}
                {...other}
            />
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            size: 'small',
            inputVariant: 'outlined',
            autoOk: true,
        } as any,
    },
);

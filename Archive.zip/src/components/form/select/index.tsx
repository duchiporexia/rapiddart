import React from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { SelectOptionsType } from '../common/option';

export const FSelect = rst.createS<{
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    options: Array<SelectOptionsType>;
    fullWidth?: boolean;
    variant?: 'standard' | 'filled' | 'outlined';
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
}>(
    (props) => {
        const {
            label,
            form: { dirty, touched, errors, setFieldValue },
            field: { name, value },
            options,
            variant,
            ...other
        } = props;
        const id = `sel_${name}`;
        const errorText = getIn(errors, name);
        const touchedVal = getIn(touched, name);
        const hasError = dirty && touchedVal && errorText !== undefined;

        return (
            <TextField
                select
                label={label}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onChange={(e) => setFieldValue(name, e.target.value)}
                value={value}
                variant={variant}
                {...other}>
                {options.map((item) => (
                    <MenuItem key={`${id}_${item.value}`} value={item.value}>
                        {item.label}
                    </MenuItem>
                ))}
            </TextField>
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            variant: 'outlined',
            size: 'small',
        },
    },
);

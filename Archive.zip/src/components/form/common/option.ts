export interface SelectOptionsType {
    label: string;
    value: string | number;
}

import React from 'react';
import TextField, { TextFieldProps } from '@material-ui/core/TextField';
import { Field, FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { InputProps } from '@material-ui/core/Input';
import { rst } from 'rt-state';

export const FTextField = rst.createS<FTextFieldProps>(
    (props) => {
        const {
            label,
            field,
            form: { dirty, touched, errors },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = dirty && touchedVal && errorText !== undefined;

        return (
            <TextField label={label} error={hasError} helperText={hasError ? errorText : ''} {...field} {...other} />
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
            variant: 'outlined',
            size: 'small',
        } as any,
    },
);

export type FTextFieldProps = {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    inputProps?: InputProps;
} & TextFieldProps;

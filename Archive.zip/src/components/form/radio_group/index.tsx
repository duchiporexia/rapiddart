import React from 'react';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormLabel from '@material-ui/core/FormLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { RadioGroupOptionsType } from '../index';
import { rst } from 'rt-state';

export const FRadioGroup = rst.createS<FRadioGroupProps>(
    (props) => {
        const {
            label,
            field,
            form: { touched, errors, setFieldValue },
            options,
            required,
            fullWidth,
            margin,
            size,
            classes: { formControl, formLabel, radioGroup, formControlLabel, radio, formHelperText },
            ...other
        } = props;
        const errorText = getIn(errors, field.name);
        const touchedVal = getIn(touched, field.name);
        const hasError = touchedVal && errorText !== undefined;
        return (
            <FormControl
                component="fieldset"
                fullWidth={fullWidth}
                margin={margin}
                required={required}
                error={hasError}
                className={formControl}
                {...other}>
                <FormLabel className={formLabel}>{label}</FormLabel>
                <RadioGroup
                    aria-label={label}
                    name={field.name}
                    value={field.value}
                    onChange={(event) => setFieldValue(field.name, event.target.value)}
                    className={radioGroup}>
                    {options.map((item) => (
                        <FormControlLabel
                            key={`${item.label}_${item.value}`}
                            value={item.value}
                            control={<Radio size={size} className={radio} />}
                            label={item.label}
                            className={formControlLabel}
                        />
                    ))}
                </RadioGroup>
                {hasError && <FormHelperText className={formHelperText}>{errorText}</FormHelperText>}
            </FormControl>
        );
    },
    {
        defaultProps: {
            required: false,
            fullWidth: true,
            margin: 'normal',
            size: 'small',
            classes: undefined,
        } as any,
    },
);

export interface FRadioClasses {
    formControl?: string;
    formLabel?: string;
    radioGroup?: string;
    formControlLabel?: string;
    radio?: string;
    formHelperText?: string;
}

export interface FRadioGroupProps {
    label?: string;
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
    options: Array<RadioGroupOptionsType>;
    required?: boolean;
    fullWidth?: boolean;
    margin?: 'none' | 'dense' | 'normal';
    size?: 'small' | 'medium';
    classes?: FRadioClasses;
}

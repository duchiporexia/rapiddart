import { SelectOptionsType } from '../common/option';
import * as React from 'react';

export interface CascadingSelectOptionsType extends SelectOptionsType {
    children?: CascadingSelectOptionsType[];
}

export const ParentPopupState = React.createContext(null);

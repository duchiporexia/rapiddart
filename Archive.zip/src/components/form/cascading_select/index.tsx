import React from 'react';
import { FieldInputProps, FormikProps, FormikValues, getIn } from 'formik';
import { rst } from 'rt-state';
import { CascadingSelect, CascadingSelectProps } from './cascading_select';

export interface FCascadingSelectProps extends CascadingSelectProps {
    field: FieldInputProps<any>;
    form: FormikProps<FormikValues>;
}

export const FCascadingSelect = rst.createS<FCascadingSelectProps>(
    (props) => {
        const {
            form: { dirty, touched, errors, setFieldValue },
            field: { name, value },
            options,
            variant,
            ...other
        } = props;
        const errorText = getIn(errors, name);
        const touchedVal = getIn(touched, name);
        const hasError = dirty && touchedVal && errorText !== undefined;

        return (
            <CascadingSelect
                variant={variant}
                options={options}
                error={hasError}
                helperText={hasError ? errorText : ''}
                onSelected={(value) => setFieldValue(name, value)}
                value={value}
                {...other}
            />
        );
    },
    {
        defaultProps: {
            fullWidth: true,
            margin: 'normal',
        },
    },
);

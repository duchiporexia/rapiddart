import * as React from 'react';
import { themeOptions } from './theme';
import { createMuiTheme } from '@material-ui/core/styles';
import { rst } from 'rt-state';
import { PaletteType } from '@material-ui/core';

export const getPrefersDarkMode = () => {
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
};

export const AppProvider = rst.createProvider(() => {
    const prefersDarkMode = getPrefersDarkMode();

    const state = rst.state<{ themeMode: PaletteType }>({
        themeMode: prefersDarkMode ? 'dark' : 'light',
    });

    const toggleThemeMode = () => {
        state.themeMode = getNextThemeMode();
    };

    const getNextThemeMode = () => {
        return state.themeMode === 'light' ? 'dark' : 'light';
    };

    const getTheme = () => {
        themeOptions.palette.type = state.themeMode;
        return createMuiTheme(themeOptions);
    };

    return { state, toggleThemeMode, getTheme, getNextThemeMode };
});

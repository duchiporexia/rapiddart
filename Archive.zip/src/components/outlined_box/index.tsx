import { Button, InputAdornment, TextField, TextFieldProps } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import * as React from 'react';

export const OutlinedBox: React.FC<
    {
        hasData: boolean;
        onClick: (e: any) => void;
        onClear: () => void;
    } & TextFieldProps
> = (props) => {
    const { hasData, children, onClick, onClear, ...others } = props;

    const moreProps: TextFieldProps = {
        ...others,
        multiline: hasData,
        variant: 'outlined',
    };
    const _onClear = (e) => {
        e.stopPropagation();
        onClear();
    };
    const myInputProps = {
        inputComponent: ({ inputRef, children, ...other }) => {
            if (hasData) {
                return (
                    <>
                        <div {...other} />
                    </>
                );
            }
            const more = { ...other, readonly: 'readonly' } as any;
            return <input ref={inputRef} {...more} />;
        }, // <div {...other} />, // <input ref={inputRef} {...other} />,
        endAdornment: (
            <InputAdornment position="end">
                {hasData ? (
                    <Button onClick={_onClear} size={'small'} style={{ color: 'grey' }}>
                        CLEAR
                    </Button>
                ) : null}
            </InputAdornment>
        ),
    } as any;
    const myInputLabelProps = {
        shrink: hasData,
    } as any;

    return (
        <TextField
            select
            onClick={onClick}
            {...moreProps}
            InputLabelProps={myInputLabelProps}
            InputProps={myInputProps}
            inputProps={{ children }}
        />
    );
};

import React from 'react';
import { create, state, stateV, stateF, watch, unwatch } from './reactive';
import { render } from 'react-dom';

const delay = (ms: number) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

const data = state({ count: 0, num: {v1: 0, v2: 100} });

const App = create((ctx) => {
  console.log('App setup');
  // watch(async (values, oldValues) => {
  //     console.log(`values:`, values, `oldValues:`, oldValues);
  //     // await delay(3000);
  //     // if (!ctx.active) {
  //     //     console.log('is inactive');
  //     //     return;
  //     // }
  //     // data.count++;
  //   }, () => [data.count, data.num]
  // );

  return () => {
      console.log('App render');
      return (
          <div>
              {/*<div>{JSON.stringify(data.num)}</div>*/}
              <ShowCountParent />
              <button onClick={() => {
                  data.count++;
                  data.num.v1 += 1;
                  // data.num.v2 += 100;
              }}>+</button>
              <NestedParentComp />
              {/*<ShowCountStateFChild />*/}
              {/*<ShowNum data={data}/>*/}
              {data.num.v1 % 10 !== 0 ? <ShowNumField numV1={data.num.v1} numV2={data.num.v2}/> : null }

          </div>
      )
  }
});

const ShowNum = create<{data: {num: {v1: number, v2: number}}}>(() => {
    console.log('ShowNum: setup');
    return (props) => {
        console.log('ShowNum render');
        return <div>ShowNum:{JSON.stringify(props.data.num)}</div>;
    }
});

const ShowNumField = create<{numV1: number, numV2: number}>((ctx) => {
    console.log(`ShowNumField setup: ${ctx.props.numV1} ${ctx.props.numV2}`);
    const watcher = watch(async () => {
        if (ctx.props.numV1 > 3) {
            console.log('unwatch');
            unwatch(watcher);
            return;
        }
        console.log(`ShowNumField watch start: ${ctx.props.numV1}  ${ctx.props.numV2}...`);
        await delay(3000);
        console.log(`ShowNumField watch done: ${ctx.active} ${watcher.active}: ${ctx.props.numV1}  ${ctx.props.numV2}`);
    }, () => [ctx.w().numV1]);

    // unwatch(watcher);

    ctx.onClose(() => {
        console.log(`ShowNumField teardown: ${ctx.props.numV1}  ${ctx.props.numV2} `);
    });
    return (props) => {
        console.log(`ShowNumField render: ${props.numV1}  ${props.numV2} `);
        return <div>numV:{props.numV1} {props.numV2}</div>;
    }
});


const ShowCountParent = create(() => {
    console.log('ShowCountParent setup');

    return () => {
        console.log('ShowCountParent: render');
        return <>
            <div>good</div>
            <ShowCount name={'ShowCount'} />
        </>;
    }
});

const ShowCount = create<{name: string}>(() => {
    console.log('ShowCount setup');

    return (props) => {
        const {count} = data;
        console.log(`ShowCount: render`);
        return <div>
            {props.name}: {count}
            <ShowCountChild name={'ShowCountChild'} count={null}/>
            <ShowCountStateFChild />
            <ShowCountStateVChild name={'ShowCountStateVChild'}/>
        </div>;
    };
});

const ShowCountStateVChild = create<{name: string}>(() => {
    console.log(`ShowCountStateVChild setup`);
    const one = stateV(100);
    const two = stateV(200);
    const third = state({val: 300});

    const plusOne = () => {
        one.value++;
    };
    watch(() => {
        console.log('one:', one.value);
    }, () => [one.value]);

    return (props) => {
        console.log(`ShowCountStateVChild render`);
        return <div>
            <span>{props.name}</span>&nbsp;&nbsp;
            <span>{one.value}</span> &nbsp;&nbsp;
            <span>{two.value}</span>&nbsp;&nbsp;
            <span>{third.val}</span>&nbsp;&nbsp;
            <button onClick={plusOne}>add</button>
        </div>
    }
});

const ShowCountChild = create<{name: string, count: number}>(() => {
    console.log('ShowCountChild setup');
    return (props) => {
        console.log('ShowCountChild render');
        return <>
            <div>name:{props.name} {props.count}</div>
        </>;
    }
});

const ShowCountStateFChild = create(() => {
    console.log('ShowCountStateFChild setup');
    const doubleCount = stateF(() => data.count * 2);
    const doublePlusCount = stateF(() => doubleCount.value + 1000);
    return (props) => {
        console.log('ShowCountStateFChild render');
        return <>
            <div>ShowCountStateFChild: {doublePlusCount.value}</div>
        </>;
    }
});


const NestedParentComp = create(() => {
    console.log(`NestedParentComp setup`);
    const ps = state({v: 10});
    const NestedChildComp = create(() => {
        console.log(`NestedChildComp setup`);
        const cs = state({v: 100});

        return () => {
            console.log(`NestedChildComp render`);
            return <>
                <div>{cs.v} </div>
                <button onClick={()=>{
                    cs.v++;
                    data.count++;
                }}>add</button>
            </>;
        }
    });

    return () => {
        console.log(`NestedParentComp render`);
        return <>
            <NestedChildComp />
            <div>{ps.v}</div>
            <button onClick={()=>ps.v++}>add</button>
        </>;
    }
});


render(<App />, document.getElementById('root'));

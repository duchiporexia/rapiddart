import * as React from 'react';
import { Route, BrowserRouter, useHistory, Switch } from 'react-router-dom';
import { SecurityProvider } from './commons';
import { LoginPage } from './pages/login';
import { DemoPage } from './pages/demo';
import { rst } from 'rt-state';
import { jssPreset, StylesProvider, ThemeProvider } from '@material-ui/styles';
import { AppProvider } from './components/app_provider';
import { create } from 'jss';
import rtl from 'jss-rtl';
import { CssBaseline } from '@material-ui/core';

import { env } from './environments';
import { Dashboard } from './dashboard';
const noop = env;

const AuthComponent = rst.create((ctx) => {
    const { tokenInfo, isLoading } = SecurityProvider.use();

    return (props) => {
        const history = useHistory();

        if (isLoading()) {
            return <div>loading</div>;
        }

        // TODO: uncomment it.
        // if (!tokenInfo.valid) {
        //     const location = history.location;
        //     const redirect = `${location.pathname}${location.search}${location.hash}`;
        //     storage.save('redirect', redirect);
        //     return <Redirect to={'/login'} />;
        // }

        return <>{(props as any).children}</>;
    };
});

const jss = create({ plugins: [...jssPreset().plugins, rtl()] });
const App = rst.createS(
    () => {
        const appProvider = AppProvider.use();

        return (
            <ThemeProvider theme={appProvider.getTheme()}>
                <CssBaseline />
                <StylesProvider jss={jss}>
                    <BrowserRouter>
                        <Switch>
                            <Route path={'/login'} exact component={LoginPage} />
                            <Route path={'/demo'} exact component={DemoPage} />
                            <Route path={'/'} component={Dashboard} />
                            {/*<AuthComponent>*/}
                            {/*    <Route path={'/dashboard'} exact component={Dashboard} />*/}
                            {/*</AuthComponent>*/}
                        </Switch>
                    </BrowserRouter>
                </StylesProvider>
            </ThemeProvider>
        );
    },
    { providers: [SecurityProvider, AppProvider] },
);

export default App;

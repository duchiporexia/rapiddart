import { devEnv } from './dev';
import { prodEnv } from './prod';

const baseEnv = {};
const APP_ENV = (process.env.REACT_APP_ENV ?? '').trim();
console.log(`env: ${process.env.NODE_ENV} ${APP_ENV}`);

interface ENV {}

const getEnv = (): ENV => {
    const configs = {
        dev: devEnv,
        prod: prodEnv,
    };
    return { ...baseEnv, ...configs[APP_ENV] };
};
export const env = getEnv();

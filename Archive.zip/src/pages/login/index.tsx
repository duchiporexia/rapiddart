import * as React from 'react';
import { Button, Grid, Paper, Box, Typography } from '@material-ui/core';
import makeStyles from '@material-ui/core/styles/makeStyles';
import { withRouter } from 'react-router';
import { useHistory } from 'react-router-dom';
import { api, storage, SecurityProvider, formatDate } from '../../commons';
import { hooks, rst } from 'rt-state';
import { createSnackbarController, Snackbar } from '../../components/snackbar';
import { SignIn } from './sign_in';

const useStyles = makeStyles((theme) => ({
    paper: {
        height: 'auto',
        width: 380,
    },
    header: {
        backgroundColor: 'black',
        color: 'white',
        fontSize: theme.typography.h6.fontSize,
        height: theme.spacing(5),
        paddingLeft: theme.spacing(3),
    },
}));

const Header = rst.createS<{ className: string }>(({ className, children }) => {
    return (
        <Grid container justify={'flex-start'} alignItems={'center'} className={className}>
            {children}
        </Grid>
    );
});

const Login = rst.create(() => {
    const securityContextProvider = SecurityProvider.use();
    const hrd = hooks(() => {
        const history = useHistory();
        return { history };
    });

    const snackbarController = createSnackbarController();

    const onLogin = async (data) => {
        const { username, password } = data as any;
        const token = window.btoa(`${username}:${password}`);
        try {
            const result = await api.get('/api/login', { headers: { Authorization: `Basic ${token}` } });
            const jwt = result;
            console.log('jwt:', jwt);
            await securityContextProvider.setToken(jwt);
            snackbarController.open('Login success!', 'success');
            const redirect = await storage.get('redirect');
            if (redirect != null) {
                await storage.remove('redirect');
                console.log('redirect:', redirect);
                hrd.history.push(redirect);
            } else {
                hrd.history.push('/');
            }
        } catch (e) {
            snackbarController.open('Login failed.', 'error');
            console.error('login error', e);
        }
    };
    ////////////////////////////////////////////////////////////////////////
    return () => {
        return <SignIn />;
        const classes = useStyles();
        return (
            <Grid container justify={'center'} alignItems={'center'} style={{ height: '600px' }}>
                <Paper className={classes.paper}>
                    <Header className={classes.header}>
                        <Typography>Login</Typography>
                    </Header>

                    <Grid
                        container
                        item
                        xs={10}
                        spacing={2}
                        direction="column"
                        justify="space-between"
                        alignItems="center"
                        style={{ margin: 'auto', paddingTop: 30, paddingBottom: 30 }}>
                        <Box m={1} />
                        <Grid container item>
                            <Button
                                type="submit"
                                onClick={() => onLogin({ username: 'xvv', password: 'xxx' })}
                                fullWidth
                                variant="contained"
                                color="primary"
                                disableElevation>
                                LOGIN
                            </Button>
                        </Grid>
                    </Grid>
                </Paper>
                <Snackbar controller={snackbarController} />
            </Grid>
        );
    };
});

export const LoginPage = withRouter(Login);

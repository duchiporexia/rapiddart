import MaterialTable from 'material-table';
import { Button, Paper } from '@material-ui/core';
import React from 'react';
import { rst } from 'rt-state';
import { clsx } from '../../commons';

export const ActionOverriding = rst.createS<{
    classes?: any;
}>((props) => {
    return (
        <Paper className={clsx('py-1', 'px-1', props.classes?.root)}>
            <MaterialTable
                options={{
                    search: false,
                }}
                title="Action Overriding Preview"
                columns={[
                    { title: 'Name', field: 'name' },
                    { title: 'Surname', field: 'surname' },
                    { title: 'Birth Year', field: 'birthYear', type: 'numeric' },
                    {
                        title: 'Birth Place',
                        field: 'birthCity',
                        lookup: { 34: 'İstanbul', 63: 'Şanlıurfa' },
                    },
                ]}
                data={[
                    { name: 'Mehmet', surname: 'Baran', birthYear: 1987, birthCity: 63 },
                    { name: 'Zerya Betül', surname: 'Baran', birthYear: 2017, birthCity: 34 },
                ]}
                actions={[
                    {
                        icon: 'save',
                        tooltip: 'Save User',
                        isFreeAction: true,
                        onClick: (event, rowData: any) => alert('You saved ' + rowData.name),
                    },
                ]}
                components={{
                    Container: (props) => <div {...props} />,
                    Action: (props) => (
                        <Button
                            onClick={(event) => props.action.onClick(event, props.data)}
                            color="primary"
                            variant="contained"
                            style={{ textTransform: 'none' }}
                            size="small">
                            ADD
                        </Button>
                    ),
                }}
            />
        </Paper>
    );
});

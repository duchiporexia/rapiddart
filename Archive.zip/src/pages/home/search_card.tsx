import { rst } from 'rt-state';
import React from 'react';
import { Grid, Paper, Typography, Hidden } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import Box from '@material-ui/core/Box';
import { Field, Form, Formik } from 'formik';
import { array, date, mixed, object, string } from 'yup';
import { clsx } from '../../commons';
import { countries, skills } from './data';
import {
    FSelect,
    FAutocomplete,
    FTextField,
    FKeyboardTimePicker,
    FKeyboardDateTimePicker,
} from '../../components/form';

const validationSchema = object().shape({
    username: string().required('Username is required'),
    gender: string().required('Gender selection is required'),
    country: string().nullable().required('Country is required'),
    skills: array().required('At least one skill is required'),
    birthdate: date().nullable().required('Birth date is required'),
    interviewTime: mixed().required('Interview Time is required'),
});

const initialValues = {
    username: '',
    gender: 'Female',
    country: null,
    skills: [
        {
            label: 'ASP.NET',
            value: 'ASP.NET',
        },
    ],
    birthdate: null,
    interviewTime: null,
};

const onSubmit = (values) => {
    // eslint-disable-next-line no-alert
    window.alert(`
          Username: ${values.username}
          Gender: ${values.gender}
          Country: ${values.country.label}
          Skills: ${values.skills.map((v) => v.label).join(', ')}
          Birth date: ${values.birthdate}
          Interview Time: ${values.interviewTime}
        `);
};

export const FormSearchCard = rst.create<{}>((ctx) => {
    return (props) => {
        const node = (
            <Paper className={clsx('px-1', 'py-1')}>
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    validateOnBlur={false}
                    validateOnChange
                    onSubmit={onSubmit}>
                    {(formik) => (
                        <Form noValidate autoComplete="off">
                            <Grid direction={'column'} container>
                                <Grid item container>
                                    <Typography component={'div'} variant={'h6'}>
                                        <span>Search</span>
                                    </Typography>
                                    <Grid item xs />
                                    <Button
                                        variant={'contained'}
                                        onClick={(e) => {
                                            formik.resetForm();
                                        }}>
                                        Reset
                                    </Button>
                                    <Box pl={2} />
                                    <Button
                                        variant={'contained'}
                                        color={'primary'}
                                        type="submit"
                                        disabled={!formik.dirty}>
                                        Confirm
                                    </Button>
                                </Grid>
                                <Grid item>
                                    <Grid container spacing={1}>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field name="username" label="Username" component={FTextField} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="gender"
                                                label="Gender"
                                                options={[
                                                    { value: '', label: '-- No selection --' },
                                                    { value: 'Male', label: 'Male' },
                                                    { value: 'Female', label: 'Female' },
                                                    { value: 'Other', label: 'Other' },
                                                ]}
                                                component={FSelect}
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="country"
                                                label={'Country'}
                                                options={countries}
                                                component={FAutocomplete}
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="skills"
                                                label={'Skills'}
                                                options={skills}
                                                component={FAutocomplete}
                                                multiple
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="birthdate"
                                                component={FKeyboardDateTimePicker}
                                                label="Birth date"
                                                format="dd/MM/yyyy hh:mm"
                                            />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={3}>
                                            <Field
                                                name="interviewTime"
                                                label="Interview Time"
                                                component={FKeyboardTimePicker}
                                                mask="__:__"
                                                ampm={false}
                                            />
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>
                        </Form>
                    )}
                </Formik>
            </Paper>
        );

        return (
            <Hidden xsDown implementation={'css'}>
                {node}
            </Hidden>
        );
    };
});

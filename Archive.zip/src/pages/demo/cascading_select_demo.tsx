import React from 'react';
import { Box } from '@material-ui/core';
import { rst } from 'rt-state';
import { menuItems } from './data';
import { CascadingSelect } from '../../components/form/cascading_select/cascading_select';

export const CascadingSelectDemo = rst.create<{}>((ctx) => {
    const selected = rst.stateV('6');
    const onSelected = (value: any) => {
        selected.value = value;
        console.log('select:', value);
    };
    return (props) => {
        return (
            <div style={{ margin: 'auto', width: 300 }}>
                <Box pt={30} />
                <CascadingSelect
                    label={'Test'}
                    name={'test'}
                    // error={true}
                    // helperText={'error is coming'}
                    value={selected.value}
                    options={menuItems}
                    onSelected={onSelected}
                    renderValue={(value) => {
                        return value.label;
                    }}
                    renderValueWithPaths={(paths) => {
                        return paths.map((p) => p.label).join('/');
                    }}
                    // renderOption={(value) => (
                    //     <div>
                    //         {value.label}:{value.value}
                    //     </div>
                    // )}
                />
            </div>
        );
    };
});

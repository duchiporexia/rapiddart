export const menuItems = [
    {
        value: '1',
        label: 'Button 1',
    },
    {
        value: '2',
        label: 'Button 2',
    },
    {
        value: '3',
        label: 'Button 3',
    },
    {
        value: 'group-1',
        label: 'Group 1',
        children: [
            {
                value: '4',
                label: 'Button 4',
            },
            {
                value: '5',
                label: 'Button 5',
            },
            {
                value: '6',
                label: 'Button 6',
            },
        ],
    },
    {
        value: 'group-2',
        label: 'Group 2',
        children: [
            {
                value: '7',
                label: 'Button 7',
            },
            {
                value: '8',
                label: 'Button 8',
            },
            {
                value: '9',
                label: 'Button 9',
                children: [
                    {
                        value: '91',
                        label: 'Button 91',
                    },
                    {
                        value: '92',
                        label: 'Button 92',
                    },
                ],
            },
        ],
    },
];

import React from 'react';
import { Box, Grid, MenuItem, TextField, Theme } from '@material-ui/core';
import { rst } from 'rt-state';
import { makeStyles } from '@material-ui/core';
import { clsx } from '../../commons';

const useStyles = makeStyles((theme: Theme) => ({
    formControl: {
        margin: theme.spacing(1),
        minWidth: 120,
    },
    legend: {
        '&.MuiOutlinedInput-root legend': {
            width: '0 !important',
        },
    },
}));

const allOptions = [
    {
        value: 'v1',
        label: 'v1',
        children: [
            {
                value: 'v11',
                label: 'v11',
            },
            {
                value: 'v12',
                label: 'v12',
                children: [
                    {
                        value: 'v121',
                        label: 'v121',
                    },
                ],
            },
        ],
    },
    {
        value: 'v2',
        label: 'v2',
    },
];

const currencies = [
    {
        value: '',
        label: 'None',
    },
    {
        value: 'USD',
        label: '$',
    },
    {
        value: 'EUR',
        label: '€',
    },
    {
        value: 'BTC',
        label: '฿',
    },
    {
        value: 'JPY',
        label: '¥',
    },
];
const ages = [
    {
        value: '',
        label: 'None',
    },
    {
        value: 10,
        label: 'Ten',
    },
    {
        value: 20,
        label: 'Twenty',
    },
    {
        value: 30,
        label: 'Thirty',
    },
];

export const MixedFieldDemo = rst.create(() => {
    const state = rst.state({
        choice: [],
        options: [],
    });

    const getOptions = (level: number) => {
        const ret = [];
        let options = allOptions;
        for (let i = 0; i <= level; i++) {
            ret.push(options);
            const val = state.choice[i];
            const item = options.find((opt) => opt.value === val);
            if (item?.children == null) {
                break;
            }
            options = item?.children;
        }
        return ret;
    };

    const handleOptionChange = (event, level: number) => {
        if (state.choice.length < level) {
            return;
        }
        if (state.choice.length > level + 1) {
            state.choice = state.choice.slice(0, level + 1);
        }
        state.choice[level] = event.target.value;
        state.options = getOptions(level);
    };

    return () => {
        const classes = useStyles();
        const [age, setAge] = React.useState('');

        const handleChange = (event) => {
            setAge(event.target.value);
        };

        const [currency, setCurrency] = React.useState('EUR');

        const handleChangeCurry = (event) => {
            setCurrency(event.target.value);
        };

        return (
            <div style={{ margin: 'auto', width: 300 }}>
                <Box pt={30} />
                <Grid>
                    <TextField
                        className={classes.formControl}
                        select
                        name={'currency'}
                        label={'Currency'}
                        value={currency}
                        onChange={handleChangeCurry}
                        variant="outlined">
                        {currencies.map((option) => (
                            <MenuItem key={option.value} value={option.value}>
                                {option.label}
                            </MenuItem>
                        ))}
                    </TextField>
                    <TextField
                        className={clsx(classes.formControl, classes.legend)}
                        select
                        name={'age'}
                        value={age}
                        onChange={handleChange}
                        variant="outlined">
                        {ages.map((option) => (
                            <MenuItem key={option.value} value={option.value}>
                                {option.label}
                            </MenuItem>
                        ))}
                    </TextField>
                </Grid>
            </div>
        );
    };
});

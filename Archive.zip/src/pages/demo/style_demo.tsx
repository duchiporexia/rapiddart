import * as React from 'react';
import { Box } from '@material-ui/core';
import { makeStyles } from '@material-ui/styles';
import { rst } from 'rt-state';
import { clsx } from '../../commons';
import { ClassValue } from 'clsx';

const useStyles = makeStyles({
    root: {
        backgroundColor: 'blue',
        width: 100,
        height: 100,
    },
    label: {
        color: 'gray',
        fontSize: 20,
    },
});

const StyleComp = rst.createS<{
    classes?: any;
    label?: string;
}>(({ classes: outClasses, label }) => {
    const classes = useStyles();

    return (
        <div className={clsx(classes.root, outClasses?.root)}>
            <span className={clsx(classes.label, outClasses?.label)}>{label ?? 'N/A'}</span>
        </div>
    );
});

const useCustomStyles = makeStyles({
    root: {
        backgroundColor: 'red',
        width: 200,
        height: 200,
        borderWidth: 10,
        borderColor: 'yellow',
        borderStyle: 'solid',
    },
    label: {
        color: 'white',
        fontSize: 50,
    },
});

export const StyleDemo = rst.createS((props) => {
    const classes = useCustomStyles();
    return (
        <>
            <Box pt={6} />
            <div>default:</div>
            <StyleComp />
            <div>customized:</div>
            <StyleComp classes={classes} label={'Custom Label'} />
        </>
    );
});

import * as React from 'react';
import { withRouter } from 'react-router';
import { StyleDemo } from './style_demo';
import { MixedFieldDemo } from './mixedfield_demo';
import { CascadingSelectDemo } from './cascading_select_demo';

export const DemoPage = withRouter(CascadingSelectDemo);

import { format } from 'date-fns';

export const formatDate = (date: Date | string | null, dateFormat?: string): string | null => {
    if (date == null) {
        return null;
    }
    const dt = typeof date === 'string' ? new Date(date) : date;
    return format(dt, dateFormat ?? 'DD MMM YYYY');
};

export const formatDateTime = (date: Date | string | null, dateFormat?: string): string | null => {
    return formatDate(date, dateFormat ?? 'DD MMM YYYY HH:mm');
};

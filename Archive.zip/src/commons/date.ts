import dayjs from 'dayjs';

dayjs.extend(require('dayjs/plugin/customParseFormat'));
dayjs.extend(require('dayjs/plugin/advancedFormat'));

export const formatDate = (date: Date | string | null, dateFormat?: string): string | null => {
    if (date == null) {
        return null;
    }
    return dayjs(date).format(dateFormat ?? 'DD MMM YYYY');
};

export const formatDateTime = (date: Date | string | null, dateFormat?: string): string | null => {
    return formatDate(date, dateFormat ?? 'DD MMM YYYY HH:mm');
};

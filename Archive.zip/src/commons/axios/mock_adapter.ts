import MockAdapter from 'axios-mock-adapter';
import axios from 'axios';

const mockAdapter = new MockAdapter(axios, { delayResponse: 150 });

mockAdapter.onPost('/api/login').reply((config) => {
    const data = {} as any;
    data.token = config.data;
    return [200, data];
});

mockAdapter.onGet('/api/user').reply(200, {
    username: 'xvv',
    sex: 'male',
    description: 'This is my profile',
});
//////////////////////////////////
mockAdapter.onAny().passThrough();

import axios from 'axios';
// import './mock_adapter';

const TOKEN_MIN_LEN = 6;

const axiosContext = {
    auth: null,
};

export const injectToken = (token: string) => {
    if (!!token && token.length >= TOKEN_MIN_LEN) {
        axiosContext.auth = `Bearer ${token}`;
    } else {
        axiosContext.auth = null;
    }
};

export const api = {
    get: async (url: string, params?: any, headers?: any) => {
        const ret = await axios.get(url, { params, headers });
        return ret.data;
    },
    post: async (url: string, data?: any, headers?: any) => {
        const ret = await axios.post(url, data, { headers });
        return ret.data;
    },
    put: async (url: string, data?: any, headers?: any) => {
        const ret = await axios.put(url, data, { headers });
        return ret.data;
    },
    delete: async (url: string, params?: any, headers?: any) => {
        const ret = await axios.delete(url, { params, headers });
        return ret.data;
    },
};

axios.interceptors.request.use(
    (config) => {
        const auth = config.headers.Authorization as string;
        if (auth == null || !auth.startsWith('Basic')) {
            if (axiosContext.auth) {
                config.headers.Authorization = axiosContext.auth;
            }
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    },
);

axios.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        return Promise.reject(error);
    },
);

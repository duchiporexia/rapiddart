import { Permission } from '../permission';
export const page_one = {
    role1: {
        button1: Permission.CAN_CLICK,
        text1: [Permission.EDITABLE, Permission.READ_ONLY],
    },
};

import { AccessControlConfig } from './config';
import { page_one } from './access_control/page_one';

export const ACCESS_CONTROL_CONFIGS = {
    page_one,
} as { [namespace: string]: AccessControlConfig };

export const getPermissionsByNamespace = (roles: string[], namespace: string, resource: string) => {
    const config = ACCESS_CONTROL_CONFIGS[namespace];
    const permissions = {} as any;
    if (roles == null) {
        return permissions;
    }
    roles.forEach((role) => {
        const rscPerms = config[role];
        if (rscPerms != null) {
            const perms = rscPerms[resource];
            if (perms != null) {
                if (Array.isArray(perms)) {
                    perms.forEach((perm) => {
                        permissions[perm] = true;
                    });
                } else {
                    permissions[perms] = true;
                }
            }
        }
    });
    return permissions;
};

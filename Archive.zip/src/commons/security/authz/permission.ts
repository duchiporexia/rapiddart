export enum Permission {
    EDITABLE = 1,
    READ_ONLY = 2,
    CAN_CLICK = 3,
}

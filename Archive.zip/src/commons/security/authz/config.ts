import { Permission } from './permission';

export interface AccessControlConfig {
    [role: string]: {
        [resource: string]: Permission | Permission[];
    };
}

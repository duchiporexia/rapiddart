import 'package:flutter/material.dart';
import '../../../common/common.dart';
import 'nav_bar_item.dart';
import 'nav_bar_logo.dart';

class NavigationBar extends StatelessWidget {
  final VoidCallback openDrawer;
  NavigationBar(this.openDrawer);
  @override
  Widget build(BuildContext context) {
    return ScreenTypeLayout(
      mobile: NavigationBarMobile(openDrawer),
      desktop: NavigationBarTabletDesktop(),
    );
  }
}

class NavigationBarTabletDesktop extends StatelessWidget {
  const NavigationBarTabletDesktop({Key key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          NavBarLogo(),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              NavBarItem('Episodes'),
              SizedBox(
                width: 60,
              ),
              NavBarItem('About'),
            ],
          )
        ],
      ),
    );
  }
}

class NavigationBarMobile extends StatelessWidget {
  final VoidCallback openDrawer;
  NavigationBarMobile(this.openDrawer);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 80,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(icon: Icon(Icons.menu), onPressed: openDrawer),
            NavBarLogo(),
          ],
        )
    );
  }
}

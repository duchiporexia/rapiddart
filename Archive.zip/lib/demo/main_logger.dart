import 'package:flutter/material.dart';
import '../common/common.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    LogUtil.setLogLevel(LogUtil.LEVEL_DEBUG);

    logger.info('desktop:${GetPlatform.isDesktop}, isWeb:${GetPlatform.isWeb}, isWindows: ${GetPlatform.isWindows}, isMac: ${GetPlatform.isMacOS}');
    logger.info('duchipore@qq.com'.isEmail);

    logger.debug('debug xxx', tag: 't1');
    logger.info('info xxx');
    logger.warn('warn xxx');
    logger.error('error xxx');
    logger.debug('debug xxx', tag: 't1');
    logger.info('info xxx');
    logger.warn('warn xxx');
    logger.error('error xxx');
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      home: First(),
    );
  }
}

class First extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('First Page'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {},
          child: Text('Open'),
        ),
      ),
    );
  }
}

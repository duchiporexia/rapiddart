import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import '../router/not_found_page.dart';

void main() {
  PageRouter.initRoutes();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'fluro demo',
      onGenerateRoute: PageRouter.router.generator,
    );
  }
}

class PageRouter {
  static final router = FluroRouter();
  static void initRoutes() {

    router.notFoundHandler = Handler(handlerFunc: (context, params) {
      return NotFoundPage(
        name: 'this is notfound page',
      );
    });
    _allRoutes.forEach((path, handler) {
      router.define(path, handler: Handler(handlerFunc: handler));
    });
  }

  static final Map<String, HandlerFunc> _allRoutes = {
    '/': (context, params) {
      return LoginPage();
    },
    '/home/:userId': (context, params) {
      return HomePage(int.parse(params['userId'].first));
    },
  };

  static Future goToHomePage(BuildContext context, int userId) {
    return router.navigateTo(context, '/home/$userId');
  }
}

class LoginPage extends StatelessWidget {
  const LoginPage({Key key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Center(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('login page'),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    PageRouter.goToHomePage(context, 3).then((value) {
                      print('val:$value');
                    });
                  },
                  child: Text('home page'),
                ),
              ],
            ),
          ),
        ));
  }
}

class HomePage extends StatelessWidget {
  const HomePage(this.userId, {Key key});
  final int userId;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('userId:$userId'),
              ElevatedButton(
                onPressed: () {
                  PageRouter.router.pop(context, 'good:$userId');
                },
                child: Text('back'),
              )
            ],
          )),
    );
  }
}

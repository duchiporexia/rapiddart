import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import '../common/i18n/export.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(EasyLocalization(
      supportedLocales: kSupportedLocales,
      path: 'assets/translations',
      fallbackLocale: kLocaleEn,
      child: MyApp()
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      debugShowCheckedModeBanner: false,
      title: 'i18n demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(title: 'i18n Demo'),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({ Key key, this.title}) : super(key: key);

  final String title;

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    const test = 'test';
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            OutlinedButton( onPressed: (){
              var locale = context.locale;
              print(context.locale);
              if (locale == kLocaleEn) {
                context.locale = kLocaleZh;
              } else {
                context.locale = kLocaleEn;
              }
            }, child: Text('change lan')),
            Text('title'.tr()),
            Text(test.tr(args: ['xvv1'])),
            Text('test'.tr(args: ['xvv2'])),
          ],
        ),
      ),
    );
  }
}

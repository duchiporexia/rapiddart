import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../common/common.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'XForm Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        body: createLoginPage(name: 'XForm Demo'),
      ),
    );
  }
}

class User {
  String username;
  String email;
  String password;

  User({this.username, this.email, this.password});
}

Widget createLoginPage({String name}) {
  print('createLoginPage');
  final form = XForm<User>(User(username: '', email: '', password: ''));
  void _onLogin(XStateContext ctx) {
    ctx.setState(() {
      form.autovalidateMode = AutovalidateMode.always;
      if (form.validate()) {
        form.save();
        print(form.state.email);
        print(form.state.password);
      }
    });
  }

  return view((ctx) {
    print('createLoginPage view');
    return Form(
        key: form.key,
        autovalidateMode: form.autovalidateMode,
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: <Widget>[
              customTextField(
                labelText: 'EMAIL ADDRESS',
                validator: ValidationBuilder().email().build(),
                onSaved: (String value) {
                  form.state.email = value;
                },
              ),
              customTextField(
                labelText: 'PASSWORD',
                isPassword: true,
                validator: ValidationBuilder().required().build(),
                onSaved: (String value) {
                  form.state.password = value;
                },
              ),
              Padding(
                padding: EdgeInsets.symmetric(vertical: 30, horizontal: 20),
                child: SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () => _onLogin(ctx),
                    style: ElevatedButton.styleFrom(primary: Colors.teal),
                    child: Text('Login'),
                  ),
                ),
              )
            ],
          ),
        ));
  });
}

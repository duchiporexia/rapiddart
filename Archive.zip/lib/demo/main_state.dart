import 'package:flutter/material.dart';
import '../common/common.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'XState Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainPage(name: 'XState Demo'),
    );
  }
}
class Person {
  String name;
  int age;
  Person({this.name, this.age});
  //////////////////////////////////

  Future<void> changeNameAndAgeDelayed() async {
    name = await Future.delayed(const Duration(seconds: 1), () => 'a${age}n');
    age++;
  }
}

class Dog {
  String name;
  String master;
  int age;
  Dog({this.name, this.master, this.age});
}

final gPersonState = XState(Person(name: 'zm', age: 118));

void addGAge() {
  gPersonState.value.age++;
  gPersonState.update();
}

class MainPage extends StatelessWidget {
  final String name;
  MainPage({this.name});
  final personState = XState(Person(name: 'xvv', age: 18));
  final dogState = XState(Dog(name: 'dog1', master: 'xvv', age: 2));

  void changeNameAndAgeDelayed() async {
    await personState.value.changeNameAndAgeDelayed();
    personState.update();
  }

  void doubleName() {
    var person = personState.value;
    person.name = '${person.name}${person.name}';
    personState.update();
  }

  void addAge() {
    personState.value.age++;
    personState.update();
  }

  @override
  Widget build(BuildContext context) {
    print('MainPage page render.');
    return Scaffold(
        appBar: AppBar(
          title: Text(name),
        ),
        body: Align(
          alignment: Alignment.topCenter,
          child: SingleChildScrollView(
            child: Column(children: [
              OutlinedButton( onPressed: addGAge, child: Text('addGAge')),
              OutlinedButton( onPressed: addAge, child: Text('addAge')),
              OutlinedButton( onPressed: doubleName, child: Text('doubleName')),
              OutlinedButton(
                  onPressed: changeNameAndAgeDelayed,
                  child: Text('change NameAndAge Delay 1 second')),
              SizedBox(height: 20),
              Text('nonReactive name:${personState.value.name}',
                  style: TextStyle(fontSize: 22)),
              view((ctx) => Text('reactive name:${personState.value.name}')),
              PersonNameWidget(),
              PersonAgeWidget(),
            ]).provideX(personState).provideX(dogState),
          ),
        ));
  }
}


class PersonNameWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return view((ctx) {
      print('PersonNameWidget render');

      final personState = ctx.get<XState<Person>>();
      final person = personState?.value;

      ctx.useWatch((v, ov) {
        print('v:$v');
        if ((v[0] as int) == 126) {
          ctx.update();
        }
      },() => [gPersonState.value.age, 10]);

      final newPerson = ctx.useSetup(() {
        return Person(name: 'new person', age: 100);
      });

      print('newPerson name:${newPerson.name}');

      ctx.dispose(() {
        print('dispose PersonNameWidget');
      });

      return addBorder(Column(
        children: <Widget>[
          Text('PersonNameWidget', style: TextStyle(fontSize: 25)),
          Text('name:${person?.name ?? 'null'}', style: TextStyle(fontSize: 20))
        ],
      ));
    });
  }
}

class PersonAgeWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return view((ctx) {
      print('PersonAgeWidget render');
      final person = ctx.get<XState<Person>>()?.value;
      final dog = ctx.get<XState<Dog>>()?.value;

      return addBorder(Column(
        children: <Widget>[
          Text('PersonAgeWidget', style: TextStyle(fontSize: 25)),
          Text('age:${person?.age}', style: TextStyle(fontSize: 20)),
          Text('dog name:${dog?.name} ${dog.master} ${dog.age}', style: TextStyle(fontSize: 20)),
        ],
      ));
    });
  }
}

Widget addBorder(Widget child) {
  return Container(
    margin: EdgeInsets.all(10),
    decoration: BoxDecoration(
      border: Border.all(),
    ),
    child: child,
  );
}

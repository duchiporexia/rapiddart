import '../dto/signup_type.dart';

import '../dto/session_po.dart';
import '../dto/err_response.dart';
import '../common/env/env.dart';
import 'package:test/test.dart';
import 'user.dart';

void main() {
  Env.init();
  test('testSignup', testSignup, timeout: Timeout.none);
  // test('testSession', testSession, timeout: Timeout.none);
  // test('testLogin', testLogin, timeout: Timeout.none);
}

void testSignup() async {
  await dumpErrIfNeed(() => signup(SignupType.Email, 'duchiporexia.surfacego@gmail.com', 'xvvpwd'));
}

void testSession() async {
  await dumpErrIfNeed(() async {
    var po = SessionPo();
    po.token = '31690555134050307';
    po.source = 10001;
    po.uuid = '8d654978-2ee5-4b2d-8591-f9390397dd16';
    var tokenAndSession = await session(po);
    print(tokenAndSession.toJson());
  });
}

void testLogin() async {
  await dumpErrIfNeed(() async {
    var tokenAndSession = await login('duchiporexia.surfacego@gmail.com', 'xvvpwd');
    print(tokenAndSession.toJson());
  });
}



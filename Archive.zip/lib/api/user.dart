import 'dart:convert';
import 'dart:io';

import '../dto/session_po.dart';
import '../dto/token_and_session.dart';
import '../dto/user.dart';
import '../dto/signup_type.dart';
import '../dto/change_password_po.dart';
import '../dto/update_user_po.dart';
import '../common/env/env.dart';
import '../common/http/http.dart';
import '../common/http/api.dart';
import '../common/http/mapi.dart';

final _mapiNoToken = MAPI(API());

String userPath(String path) {
  return  '${Env.BACKEND_URL}/user$path';
}

///////////////////////////////////////////////////
Future loginOauth(String source) async {
  return _mapiNoToken.get(userPath('/oauth/$source'));
}
///////////////////////////////////////////////////
Future<TokenAndSession> session(SessionPo po) async {
  var data = await _mapiNoToken.post(userPath('/session'), po.toJson());
  return TokenAndSession.fromJson(data);
}

Future<void> signup(int signupType, String username, String password) {
  var basicAuth = 'Basic ' + base64Encode(utf8.encode('$username:$password'));
  return _mapiNoToken.get(userPath('/signup?type=$signupType'), headers: {HttpHeaders.authorizationHeader: basicAuth});
}

Future<TokenAndSession> login(String username, String password) async {
  var basicAuth = 'Basic ' + base64Encode(utf8.encode('$username:$password'));
  var data = await _mapiNoToken.get(userPath('/login'), headers: {HttpHeaders.authorizationHeader: basicAuth});
  return TokenAndSession.fromJson(data);
}

Future<void> forgetPassword(String email, String password) async {
  var basicAuth = 'Basic ' + base64Encode(utf8.encode('$email:$password'));
  return _mapiNoToken.get(userPath('/forget_password'), headers: {HttpHeaders.authorizationHeader: basicAuth});
}

Future<TokenAndSession> refreshToken(TokenAndSession tokenAndSession) async {
  var data = await _mapiNoToken.post(userPath('/refresh_token'), tokenAndSession.toJson());
  return TokenAndSession.fromJson(data);
}

///////////////////////////////////////////////////////////////

Future<User> profile() async {
  var data = await mapi.get(userPath('/profile'));
  return User.fromJson(data);
}

Future<User> updateProfile(UpdateUserPo po) async {
  var data = await mapi.post(userPath('/profile'), po.toJson());
  return User.fromJson(data);
}

Future<void> changePassword(ChangePasswordPo po) async {
  await mapi.post(userPath('/change_password'), po.toJson());
}

import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';
import '../pages/user/signup_page.dart';
import '../pages/user/login_page.dart';
import '../pages/user/welcome_page.dart';

import 'not_found_page.dart';

class PageRouter {
  static final router = FluroRouter();
  static void initRoutes() {

    router.notFoundHandler = Handler(handlerFunc: (context, params) {
      return NotFoundPage(
        name: 'this is notfound page',
      );
    });
    _allRoutes.forEach((path, handler) {
      router.define(path, handler: Handler(handlerFunc: handler), transitionType: TransitionType.fadeIn);
    });
  }

  static final Map<String, HandlerFunc> _allRoutes = {
    '/': (context, params) {
      return WelcomePage();
    },
    '/login': (context, params) {
      return LoginPage();
    },
    '/signup':  (context, params) {
      return SignupPage();
    },
  };

  static Future loginPage(BuildContext context) {
    return router.navigateTo(context, '/login');
  }
  static Future signupPage(BuildContext context) {
    return router.navigateTo(context, '/signup');
  }
}

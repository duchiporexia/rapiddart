import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'constants/app_colors.dart';
import 'router/page_router.dart';
import 'common/env/env.dart';
import 'common/i18n/export.dart';
import 'common/logger.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  LogUtil.setLogLevel(LogUtil.LEVEL_DEBUG);
  Env.init();
  PageRouter.initRoutes();
  runApp(EasyLocalization(
      supportedLocales: kSupportedLocales,
      path: 'assets/translations',
      fallbackLocale: kLocaleEn,
      child: MyApp()
  ));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) {
        var currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus) {
          currentFocus.focusedChild?.unfocus();
        }
      },
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'UI',
        theme: ThemeData(
          primarySwatch: kPrimaryColor,
          visualDensity: VisualDensity.adaptivePlatformDensity,
          textTheme: Theme.of(context).textTheme.apply(fontFamily: 'NotoSansSC'),
          iconTheme: IconThemeData(
            color: kPrimaryColor,
          ),
        ),
        onGenerateRoute: PageRouter.router.generator,
      ),
    );
  }
}

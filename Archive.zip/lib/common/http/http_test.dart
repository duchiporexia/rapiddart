import 'package:test/test.dart';
import '../msgpack_dart/msgpack_dart.dart';
import 'http.dart';

void main() {
  test('callFooAPI', callFooAPI);
  test('testFoo', testFoo);
}

void callFooAPI() async {
  var data = await mapi.post('http://localhost:3030/foo/180', foo);
  expect(data['age'], 198);
  data['age'] = 18;
  expect(data, foo);
}

void testFoo() {
  var data = MsgX.encode(foo);
  var value = MsgX.decode(data);
  expect(foo, value);
}

Map<String, dynamic> foo = {
  'id': '9223372036854775807',
  'name': 'Hello, world!',
  'age': 18,
  'map': { 'k1': 'v1' },
  'map2': {
    'd1': {
      'name': 'dog1',
      'age': 3,
    },
  },
  'arr': ['i1', 'i3'],
  'arr2': [
    {
      'name': 'dog1',
      'age': 3,
    },
    {
      'name': 'd2',
      'age': 1000,
    },
  ],
  'dog': {
    'name': 'dog1',
    'age': 3,
  },
  'dog2': {
    'name': 'd2',
    'age': 1000,
  },
  'createTime': DateTime.parse('2020-01-01'),
  'updateTime': null,
};

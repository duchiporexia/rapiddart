import 'dart:typed_data';
import '../msgpack_dart/msgpack_dart.dart';
import 'api.dart';

class MAPI {
  final API _api;
  MAPI(API api): _api=api;

  Future<Map<String, dynamic>> get(String path, {Map<String, dynamic> query, Map<String, dynamic> headers}) async {
    var data = await _api.get(path, query: query, headers: headers, isBinary: true) as List<int>;
    if (data == null || data.isEmpty) {
      return null;
    }
    var value = MsgX.decode(Uint8List.fromList(data));
    return Map<String, dynamic>.from(value as Map<dynamic, dynamic>);
  }

  Future<Map<String, dynamic>> post(String path, dynamic data, {Map<String, dynamic> headers}) async {
    var encoded = MsgX.encode(data);
    var retData = await _api.post(path, encoded, headers: headers, isBinary: true) as List<int>;
    if (retData == null || retData.isEmpty) {
      return null;
    }
    var value = MsgX.decode(Uint8List.fromList(retData));
    return Map<String, dynamic>.from(value as Map<dynamic, dynamic>);
  }
}

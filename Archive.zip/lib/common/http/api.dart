import 'dart:io';
import 'package:dio/dio.dart';

class API {
  final Dio _dio;
  API(): _dio=Dio();

  void addInterceptor(Interceptor interceptor) {
    _dio.interceptors.add(interceptor);
  }

  Future get(String path, {Map<String, dynamic> query, Map<String, dynamic> headers, bool isBinary}) async {
    Options options;
    if (isBinary != null && isBinary) {
      headers ??= {};
      options = Options(responseType: ResponseType.bytes, headers: headers);
    } else {
      options = Options(headers: headers);
    }
    var resp = await _dio.get(path, queryParameters: query, options: options);
    return resp.data;
  }

  Future post(String path, dynamic data, {Map<String, dynamic> headers, bool isBinary}) async {
    Options options;
    if (isBinary != null && isBinary) {
      var postData = <int>[...data];
      data = Stream<List<int>>.fromIterable(postData.map((e) => [e])); //create a Stream<List<int>>
      headers ??= {};
      headers[HttpHeaders.contentLengthHeader] = postData.length;
      options = Options(responseType: ResponseType.bytes, headers: headers);
    } else {
      options = Options(headers: headers);
    }
    var resp = await _dio.post(path, data: data, options: options);
    return resp.data;
  }

  Future put(String path, dynamic data, {Map<String, dynamic> headers}) async {
    var resp = await _dio.put(path, data: data, options: Options(headers: headers));
    return resp.data;
  }

  Future delete(String path, Map<String, dynamic> query, {Map<String, dynamic> headers}) async {
    var resp = await _dio.delete(path, queryParameters: query, options: Options(headers: headers));
    return resp.data;
  }
}

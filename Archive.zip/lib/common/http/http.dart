import 'api.dart';
import 'interceptor.dart';
import 'mapi.dart';

final api = API()..addInterceptor(CustomInterceptors());
final mapi = MAPI(api);

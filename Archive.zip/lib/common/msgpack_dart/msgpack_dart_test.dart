import 'package:test/test.dart';
import 'msgpack_dart.dart';

var isString = predicate((e) => e is String, 'is a String');
var isInt = predicate((e) => e is int, 'is an int');
var isMap = predicate((e) => e is Map, 'is a Map');
var isList = predicate((e) => e is List, 'is a List');

void main() {
  test('Test Pack null', packNull);

  group('Test Pack Boolean', () {
    test('Pack boolean false', packFalse);
    test('Pack boolean true', packTrue);
  });
  test('unpackDateTime', unpackDateTime);
}
void packNull() {
  List<int> encoded = MsgX.encode(null);
  expect(encoded, orderedEquals([0xc0]));
}
void packFalse() {
  List<int> encoded = MsgX.encode(false);
  expect(encoded, orderedEquals([0xc2]));
}

void packTrue() {
  List<int> encoded = MsgX.encode(true);
  expect(encoded, orderedEquals([0xc3]));
}
void unpackDateTime() {
  var o = DateTime.utc(2018, 8, 22, 0, 56, 56, 200);
  var data = MsgX.encode(o);
  var value = MsgX.decode(data);
  expect((value as DateTime).toUtc(),
      equals(o));
}

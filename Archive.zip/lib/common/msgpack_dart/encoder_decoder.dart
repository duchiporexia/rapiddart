part of msgpack_dart;

const DATE_TIME_TYPE = -1;

class DateTimeMsgr {
  static Uint8List encodeObject(DateTime object) {
    var bytes = Uint8List(12);
    var bytesView = ByteData.view(bytes.buffer);
    var ms = object.millisecondsSinceEpoch;
    var secs = ms ~/ 1000;
    var nanoSecs = (ms - secs * 1000) * 1000000;
    bytesView.setInt64(0, secs, Endian.little);
    bytesView.setInt32(8, nanoSecs, Endian.little);
    return bytes;
  }

  static DateTime decodeObject(Uint8List data) {
    var bytesView = ByteData.view(data.buffer, data.offsetInBytes);
    var secs = bytesView.getInt64(0, Endian.little);
    var nanoSecs = bytesView.getInt32(8, Endian.little);
    var ms = secs * 1000 + (nanoSecs ~/ 1000000);
    return DateTime.fromMillisecondsSinceEpoch(ms);
  }
}

//////////////////////////////////////////////////////
class CustomExtEncoder extends ExtEncoder {
  @override
  Uint8List encodeObject(dynamic object) {
    if (object is DateTime) {
      return DateTimeMsgr.encodeObject(object);
    }
    throw UnimplementedError();
  }

  @override
  int extTypeForObject(dynamic object) {
    if (object is DateTime) {
      return DATE_TIME_TYPE;
    }
    throw UnimplementedError();
  }
}

class CustomExtDecoder extends ExtDecoder {
  @override
  dynamic decodeObject(int extType, Uint8List data) {
    if (extType == DATE_TIME_TYPE.toUnsigned(8)) {
      return DateTimeMsgr.decodeObject(data);
    }
    throw UnimplementedError();
  }
}

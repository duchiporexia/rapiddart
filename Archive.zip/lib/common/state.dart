import 'package:flutter/widgets.dart';

_Executor _gExecutor;
////////////////////////////////////////////////////////////////////////

_XStateWidget<StateType> view<StateType>(
    Widget Function(XStateContext ctx) render,
    {Key key, String name}) {
  return _XStateWidget<StateType>(render,
      key: key, name: name);
}

class _XStateWidget<S> extends StatefulWidget {
  _XStateWidget(
      this._render, {
        Key key,
        this.name,
      }): super(key: key);

  final String name;

  final Function _render;

  @override
  State createState() {
    return _XStateWidgetState<S>();
  }
}

class _XStateWidgetState<S> extends State<_XStateWidget> {
  XStateContext _ctx;

  @override
  Widget build(BuildContext context) {
    _ctx ??= XStateContext(setState);
    _ctx.context = context;

    _ctx._cleanup();
    var oldExecutor = _gExecutor;
    _gExecutor = _ctx;
    var cached = widget._render(_ctx) as Widget;
    _gExecutor = oldExecutor;
    return cached;
  }

  @override
  void dispose() {
    _ctx._cleanup();
    if (_ctx._dispose != null) {
      _ctx._dispose();
    }
    super.dispose();
  }
}

abstract class _Executor {
  final Set<Set<_Executor>> _depsSet = <Set<_Executor>>{};
  void _cleanup() {
    _depsSet.forEach((deps) {
      deps.remove(this);
    });
    _depsSet.clear();
  }
  void _update();
}

typedef WatchCb = dynamic Function(List<dynamic> values, List<dynamic> oldValues);
typedef MemoCreateCb<T> = T Function();
typedef WatchDeps = List<dynamic> Function();

WatchExecutor _gWatchExecutor;
class WatchExecutor extends _Executor {
  WatchExecutor(this.ctx, this.fn, this.depsFunc) {
    _update();
  }
  XStateContext ctx;
  WatchCb fn;
  dynamic fnRet;
  List<dynamic> _deps;
  WatchDeps depsFunc;

  @override
  void _update() {
    if (_gWatchExecutor != null) {
      throw '_gWatchExecutor has to be null';
    }
    _gWatchExecutor = this;
    var deps = depsFunc();
    _gWatchExecutor = null;
    if (!_isEqual(deps, _deps)) {
      fnRet = fn(deps, _deps);
    }
    _deps = deps;
  }
}

class XStateContext extends _Executor{
  XStateContext(this._setState);
  BuildContext context;
  VoidCallback _dispose;
  final StateSetter _setState;
  final List<dynamic> _hookSlots = [];
  int _hookIdx = -1;
  ///////////////////////////////////
  @override
  void _update() {
    _setState(() {});
  }
  @override
  void _cleanup() {
    _cleanupHooks();
    super._cleanup();
  }

  void _cleanupHooks() {
    for (var value in _hookSlots) {
      (value as WatchExecutor)?._cleanup();
    }
    _hookIdx = -1;
  }
  ////////////////////////////////////

  void setState(VoidCallback fn) {
    _setState(fn);
  }

  void update() {
    _setState(() {});
  }

  void useWatch(WatchCb fn, WatchDeps depsFunc) {
    _watch(fn, depsFunc);
  }

  T useSetup<T>(MemoCreateCb<T> initFn) {
    return _watch((values, oldValues) => initFn(), () => []) as T;
  }

  dynamic _watch(WatchCb fn, WatchDeps depsFunc) {
    ++_hookIdx;
    WatchExecutor executor;
    if (_hookIdx > _hookSlots.length - 1) {
      executor = WatchExecutor(this, fn, depsFunc);
      _hookSlots.add(executor);
    } else {
      executor = _hookSlots[_hookIdx] as WatchExecutor;
      executor.fn = fn;
      executor.depsFunc = depsFunc;
      executor._update();
    }
    return executor.fnRet;
  }

  void dispose(VoidCallback fn) {
    _dispose = fn;
  }

  T get<T>() {
    final dataInheritedWidget = _XStateProviderWidget._of<T>(context);
    final _data = dataInheritedWidget?.data;
    return _data;
  }
}

bool _isEqual(List one, List two) {
  if (one == null || two == null) {
    return one == two;
  }
  var i = -1;
  return one.every((o) {
    i++;
    return two[i] == o;
  });
}

class XState<T> {
  XState(T value): _value=value;

  T _value;
  final Set<_Executor> _deps = <_Executor>{};

  T get value {
    _track();
    return _value;
  }

  set value(T v) {
    _value = v;
    update();
  }

  T rawValue() {
    return _value;
  }

  void _track() {
    _Executor executor;
    if (_gWatchExecutor != null) {
      executor = _gWatchExecutor;
    } else if(_gExecutor != null) {
      executor = _gExecutor;
    }
    /////////////////////////////////
    if (executor == null) {
      return;
    }
    executor._depsSet.add(_deps);
    _deps.add(executor);
  }

  void _trigger() {
    List<_Executor>.from(_deps).forEach((executor) {
      executor._update();
    });
  }

  void update() {
    _trigger();
  }
}

extension XStateProviderWidgetExtension on Widget {
  Widget provideX<T>(T data) {
    return _XStateProviderWidget<T>(this, data: data);
  }
}

class _XStateProviderWidget<T> extends InheritedWidget {
  final T data;
  _XStateProviderWidget(Widget child, {this.data}) : super(child: child);

  static _XStateProviderWidget<D> _of<D>(BuildContext context) {
    return context
        .dependOnInheritedWidgetOfExactType<_XStateProviderWidget<D>>();
  }

  @override
  bool updateShouldNotify(_XStateProviderWidget old) => data != old.data;
}

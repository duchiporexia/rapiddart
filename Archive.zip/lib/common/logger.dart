import 'package:stack_trace/stack_trace.dart';

class LogUtil {
  static const int LEVEL_DEBUG = 0;
  static const int LEVEL_INFO = 1;
  static const int LEVEL_WARN = 2;
  static const int LEVEL_ERROR = 3;

  static int _logLevel;
  static int _maxLen = 128;

  LogUtil() {
    _logLevel = LEVEL_INFO;
    _maxLen = 128;
  }

  static void setLogLevel(int logLevel) {
    _logLevel = logLevel;
  }

  void debug(Object object, {String tag}) {
    if (_logLevel <= LEVEL_DEBUG) {
      _printLog(getPrefix('\u001b[37mDEBUG\u001b[0m', tag), object);
    }
  }

  void info(Object object, {String tag}) {
    if (_logLevel <= LEVEL_INFO) {
      _printLog(getPrefix('\u001b[32mINFO\u001b[0m', tag), object);
    }
  }

  void warn(Object object, {String tag}) {
    if (_logLevel <= LEVEL_WARN) {
      _printLog(getPrefix('\u001b[33mWARN\u001b[0m', tag), object);
    }
  }

  void error(Object object, {String tag}) {
    if (_logLevel <= LEVEL_ERROR) {
      _printLog(getPrefix('\u001b[31mERROR\u001b[0m', tag), object);
    }
  }

  static String getTag(String type, String tag) {
    if (tag == null) {
      return '[$type] |';
    }
    return '[$type] | $tag |';
  }

  static String getPrefix(String type, String tag) {
    tag = getTag(type, tag);
    var frame = Trace.from(StackTrace.current).frames[3];
    var parts = frame.location.split(' ');
    var x = parts[0].split('/')..removeRange(0, 2);
    var msg = '(lib/${x.join('/')}:${frame.line})';
    if (tag == null) {
      return msg;
    }
    return '$msg $tag';
  }

  static void _printLog(String tag, Object object) {
    var da = object?.toString() ?? 'null';
    if (da.length <= _maxLen) {
      print('$tag $da');
      return;
    }
    print(
        '$tag — — — — — — — — — — — — — — — — st — — — — — — — — — — — — — — — —');
    while (da.isNotEmpty) {
      if (da.length > _maxLen) {
        print('$tag| ${da.substring(0, _maxLen)}');
        da = da.substring(_maxLen, da.length);
      } else {
        print('$tag| $da');
        da = '';
      }
    }
    print(
        '$tag — — — — — — — — — — — — — — — — ed — — — — — — — — — — — — — — — —');
  }
}

var logger = LogUtil();

import 'package:flutter/cupertino.dart';

const kLocaleZh = Locale('zh');
const kLocaleEn = Locale('en');

const kSupportedLocales = [kLocaleZh, kLocaleEn];

class Tuple2<T0, T1> {
  final T0 v0;
  final T1 v1;
  const Tuple2(this.v0, this.v1);

  @override
  String toString() => '$runtimeType: $v0, $v1';
}

class Tuple3<T0, T1, T2> {
  final T0 v0;
  final T1 v1;
  final T2 v2;
  const Tuple3(this.v0, this.v1, this.v2);

  @override
  String toString() => '$runtimeType: $v0, $v1, $v2';
}

class Tuple4<T0, T1, T2, T3> {
  final T0 v0;
  final T1 v1;
  final T2 v2;
  final T3 v3;
  const Tuple4(this.v0, this.v1, this.v2, this.v3);

  @override
  String toString() => '$runtimeType: $v0, $v1, $v2, $v3';
}

class Tuple5<T0, T1, T2, T3, T4> {
  final T0 v0;
  final T1 v1;
  final T2 v2;
  final T3 v3;
  final T4 v4;
  const Tuple5(this.v0, this.v1, this.v2, this.v3, this.v4);

  @override
  String toString() => '$runtimeType: $v0, $v1, $v2, $v3, $v4';
}

class Tuple6<T0, T1, T2, T3, T4, T5> {
  final T0 v0;
  final T1 v1;
  final T2 v2;
  final T3 v3;
  final T4 v4;
  final T5 v5;
  const Tuple6(this.v0, this.v1, this.v2, this.v3, this.v4, this.v5);

  @override
  String toString() => '$runtimeType: $v0, $v1, $v2, $v3, $v4, $v5';
}

class Tuple7<T0, T1, T2, T3, T4, T5, T6> {
  final T0 v0;
  final T1 v1;
  final T2 v2;
  final T3 v3;
  final T4 v4;
  final T5 v5;
  final T6 v6;
  const Tuple7(this.v0, this.v1, this.v2, this.v3, this.v4, this.v5, this.v6);

  @override
  String toString() => '$runtimeType: $v0, $v1, $v2, $v3, $v4, $v5, $v6';
}

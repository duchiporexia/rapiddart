import 'dart:convert';
import 'b64url_rfc7515.dart';

Map<String, dynamic> parseJwt(String token) {
  final parts = token.split('.');
  if (parts.length != 3) {
    throw Exception('invalid token');
  }


  final payload = _decodeBase64(parts[1]);
  final payloadMap = json.decode(payload);
  if (payloadMap is! Map<String, dynamic>) {
    throw Exception('invalid payload');
  }

  return payloadMap as Map<String, dynamic>;
}

String _decodeBase64(String str) {
  return B64urlEncRfc7515.decodeUtf8(str);
}


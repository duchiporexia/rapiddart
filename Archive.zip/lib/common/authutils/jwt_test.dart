import 'package:test/test.dart';

import '../logger.dart';
import 'jwt.dart';

void main() {
  test('jwtTest', jwtTest);
}

void jwtTest() {
  var token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MjQzNTUwMzksInN1YiI6IjQzNjM0NTM0NDYifQ.pC8jpuVB9n3CaYIWF0I1yqsM59ygzwf3Iw7Uv3pkTg8';
  var map = parseJwt(token);
  expect(map['sub'], '4363453446');
  expect(map['exp'], 1624355039);
}

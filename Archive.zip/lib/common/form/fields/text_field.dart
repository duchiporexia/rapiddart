import 'package:flutter/material.dart';

Widget customTextField({
  String labelText,
  FormFieldValidator<String> validator,
  FormFieldSetter<String> onSaved,
  bool isPassword = false,
  bool isEmail = false,
}) {
  print('customTextField $labelText');
  return Padding(
      padding: EdgeInsets.only(top: 30),
      child: TextFormField(
        decoration: InputDecoration(
          labelText: labelText,
          contentPadding: EdgeInsets.fromLTRB(15, -15, 15, 0),
          border: InputBorder.none,
          filled: true,
          fillColor: Colors.grey[200],
        ),
        obscureText: isPassword ? true : false,
        validator: validator,
        onSaved: onSaved,
        keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
      ));
}

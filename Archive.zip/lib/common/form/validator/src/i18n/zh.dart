import '../form_validator_locale.dart';

class LocaleZh extends FormValidatorLocale {
  @override
  String name() => 'zh';

  @override
  String minLength(String v, int n) =>
      '长度不能小于 $n 个';

  @override
  String maxLength(String v, int n) =>
      '长度不能大于 $n 个';

  @override
  String email(String v) => '邮箱地址无效';

  @override
  String phoneNumber(String v) => '电话号码无效';

  @override
  String required() => '必填';

  @override
  String ip(String v) => 'IP地址无效';

  @override
  String ipv6(String v) => 'IPv6地址无效';

  @override
  String url(String v) => 'URL地址无效';
}

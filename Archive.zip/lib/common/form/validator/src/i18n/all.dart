import '../form_validator_locale.dart';
import 'zh.dart';
import 'en.dart';


FormValidatorLocale createLocale(String locale) {
  switch (locale) {
    case 'zh':
      return LocaleZh();

    case 'en':
    case 'default':
      return LocaleEn();

    default:
      throw ArgumentError.value(
          locale, 'locale', 'Form validation locale is not available.');
  }
}

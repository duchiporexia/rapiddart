import '../form_validator_locale.dart';

class LocaleEn extends FormValidatorLocale {
  @override
  String name() => 'en';

  @override
  String minLength(String v, int n) =>
      'Must be at least $n characters long';

  @override
  String maxLength(String v, int n) =>
      'Must be at most $n characters long';

  @override
  String email(String v) => 'Invalid email address';

  @override
  String phoneNumber(String v) => 'Invalid phone number';

  @override
  String required() => 'Required';

  @override
  String ip(String v) => 'Invalid IP address';

  @override
  String ipv6(String v) => 'Invalid IPv6 address';

  @override
  String url(String v) => 'Invalid URL address';
}

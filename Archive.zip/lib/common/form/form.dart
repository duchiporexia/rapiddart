import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../state.dart';

export 'fields/text_field.dart';
export 'validator/form_validator.dart';

class XForm<T> {
  T state;
  GlobalKey<FormState> key;
  AutovalidateMode _autovalidateMode;
  WillPopCallback _onWillPop;
  VoidCallback _onChanged;
  XStateContext ctx;

  XForm(final T initValue,
      {WillPopCallback onWillPop, VoidCallback onChanged}) {
    state = initValue;
    _onWillPop = onWillPop;
    onChanged = onChanged;
    key = GlobalKey<FormState>();
    _autovalidateMode = AutovalidateMode.disabled;
  }

  AutovalidateMode get autovalidateMode => _autovalidateMode;

  set autovalidateMode(AutovalidateMode newValue) {
    if (_autovalidateMode != newValue) {
      _autovalidateMode = newValue;
    }
  }

  void save() {
    key.currentState.save();
  }

  void reset() {
    key.currentState.reset();
    _autovalidateMode = AutovalidateMode.disabled;
    ctx.update();
  }

  void setState(VoidCallback fn) {
    ctx.setState(fn);
  }

  bool validate() {
    return key.currentState.validate();
  }

  Widget child(Widget child) {
    return view((XStateContext context) {
      ctx = context;
      return Form(
        key: key,
        onWillPop: _onWillPop,
        onChanged: _onChanged,
        autovalidateMode: _autovalidateMode,
        child: child,
      );
    });
  }
}

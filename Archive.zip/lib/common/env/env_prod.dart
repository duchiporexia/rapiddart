part of 'env.dart';

void setupProd() {
  Env.BACKEND_URL = 'prod back url';
}

part of 'env.dart';

class Env {
  static String BACKEND_URL = '';

  static void init({String env}) {
    switch(env) {
      case 'prod':
        setupProd();
        break;
      default:
        setupDev();
    }
  }
}

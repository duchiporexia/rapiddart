import 'env.dart';

Future main() async {
  Env.init();
  print(Env.BACKEND_URL);
}

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'change_password_po.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChangePasswordPo _$ChangePasswordPoFromJson(Map<String, dynamic> json) {
  return ChangePasswordPo()
    ..password = json['password'] as String
    ..newPassword = json['newPassword'] as String;
}

Map<String, dynamic> _$ChangePasswordPoToJson(ChangePasswordPo instance) =>
    <String, dynamic>{
      'password': instance.password,
      'newPassword': instance.newPassword,
    };

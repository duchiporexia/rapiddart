// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'session_po.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SessionPo _$SessionPoFromJson(Map<String, dynamic> json) {
  return SessionPo()
    ..token = json['token'] as String
    ..source = json['source'] as int
    ..uuid = json['uuid'] as String;
}

Map<String, dynamic> _$SessionPoToJson(SessionPo instance) => <String, dynamic>{
      'token': instance.token,
      'source': instance.source,
      'uuid': instance.uuid,
    };

import 'package:json_annotation/json_annotation.dart';
part 'session_po.g.dart';

@JsonSerializable()
class SessionPo {
  String token;
  int source;
  String uuid;

  SessionPo();

  factory SessionPo.fromJson(Map<String, dynamic> json) => _$SessionPoFromJson(json);
  Map<String, dynamic> toJson() => _$SessionPoToJson(this);
}

import 'package:json_annotation/json_annotation.dart';

part 'token_and_session.g.dart';

@JsonSerializable()
class TokenAndSession {
  final String refreshToken;
  final String session;

  TokenAndSession({this.refreshToken, this.session});

  factory TokenAndSession.fromJson(Map<String, dynamic> json) => _$TokenAndSessionFromJson(json);
  Map<String, dynamic> toJson() => _$TokenAndSessionToJson(this);
}

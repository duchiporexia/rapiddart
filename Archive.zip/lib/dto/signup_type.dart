class SignupType {
  static const int Email = 1;
  static const int Phone = 2;
}

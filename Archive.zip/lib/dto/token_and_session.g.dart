// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'token_and_session.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TokenAndSession _$TokenAndSessionFromJson(Map<String, dynamic> json) {
  return TokenAndSession(
    refreshToken: json['refreshToken'] as String,
    session: json['session'] as String,
  );
}

Map<String, dynamic> _$TokenAndSessionToJson(TokenAndSession instance) =>
    <String, dynamic>{
      'refreshToken': instance.refreshToken,
      'session': instance.session,
    };

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'err_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ErrResponse _$ErrResponseFromJson(Map<String, dynamic> json) {
  return ErrResponse()
    ..code = json['code'] as int
    ..msg = json['msg'] as String;
}

Map<String, dynamic> _$ErrResponseToJson(ErrResponse instance) =>
    <String, dynamic>{
      'code': instance.code,
      'msg': instance.msg,
    };

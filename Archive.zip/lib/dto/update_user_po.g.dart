// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_user_po.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateUserPo _$UpdateUserPoFromJson(Map<String, dynamic> json) {
  return UpdateUserPo()
    ..username = json['username'] as String
    ..phone = json['phone'] as String
    ..firstName = json['firstName'] as String
    ..lastName = json['lastName'] as String;
}

Map<String, dynamic> _$UpdateUserPoToJson(UpdateUserPo instance) =>
    <String, dynamic>{
      'username': instance.username,
      'phone': instance.phone,
      'firstName': instance.firstName,
      'lastName': instance.lastName,
    };

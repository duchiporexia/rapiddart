import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:json_annotation/json_annotation.dart';
import '../common/msgpack_dart/msgpack_dart.dart';
part 'err_response.g.dart';

@JsonSerializable()
class ErrResponse {
  @JsonKey(ignore: true)
  int httpStatus;
  /////////////////////////////////////////////
  int code;
  String msg;

  ErrResponse();

  factory ErrResponse.fromJson(Map<String, dynamic> json) => _$ErrResponseFromJson(json);
  Map<String, dynamic> toJson() => _$ErrResponseToJson(this);

  static ErrResponse from(e) {
    print(e);
    var dioError = e as DioError;
    var data = MsgX.decode(Uint8List.fromList(dioError.response.data as List<int>)) as Map<dynamic, dynamic>;
    var errResponse = ErrResponse.fromJson(Map<String, dynamic>.from(data));
    errResponse.httpStatus = dioError.response.statusCode;
    return errResponse;
  }
}

Future dumpErrIfNeed(Function cb) async {
  try {
    return await cb();
  } catch (e) {
    var errResponse = ErrResponse.from(e);
    print('status:${errResponse.httpStatus}, code:${errResponse.code}, msg:${errResponse.msg}');
  }
}

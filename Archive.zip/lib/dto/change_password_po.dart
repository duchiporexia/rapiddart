import 'package:json_annotation/json_annotation.dart';

part 'change_password_po.g.dart';

@JsonSerializable()
class ChangePasswordPo {
  String password;
  String newPassword;
  ChangePasswordPo();

  factory ChangePasswordPo.fromJson(Map<String, dynamic> json) => _$ChangePasswordPoFromJson(json);

  Map<String, dynamic> toJson() => _$ChangePasswordPoToJson(this);

}

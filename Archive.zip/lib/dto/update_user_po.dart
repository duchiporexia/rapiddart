import 'package:json_annotation/json_annotation.dart';
part 'update_user_po.g.dart';

@JsonSerializable()
class UpdateUserPo {
  String username;
  String phone;
  String firstName;
  String lastName;

  UpdateUserPo();

  factory UpdateUserPo.fromJson(Map<String, dynamic> json) => _$UpdateUserPoFromJson(json);

  Map<String, dynamic> toJson() => _$UpdateUserPoToJson(this);
}

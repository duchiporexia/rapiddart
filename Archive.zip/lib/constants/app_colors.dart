import 'package:flutter/rendering.dart';
import '../common/color_helper.dart';

final kPrimaryColor = getMaterialColor(Color.fromARGB(255, 31, 229, 146));
const kPrimaryLightColor = Color(0xFFF1E6FF);


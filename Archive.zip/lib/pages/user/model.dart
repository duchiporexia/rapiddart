class User {
  String email;
  String password;
  String password2;

  User({this.email, this.password, this.password2});
}

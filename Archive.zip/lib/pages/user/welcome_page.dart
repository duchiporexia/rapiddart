import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import '../../router/page_router.dart';
import '../../constants/app_colors.dart';
import '../../widgets/button/rounded_button.dart';
import 'widgets/background.dart';

class WelcomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Background(
          type: BackgroundType.welcome,
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                child: ConstrainedBox(
                  constraints: constraints.copyWith(
                      minHeight: 500,// constraints.maxHeight,
                      maxHeight: double.infinity),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Text(
                        'WELCOME!',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 30),
                      SvgPicture.asset(
                        'assets/icons/chat.svg',
                        height: 200,
                      ),
                      SizedBox(height: 30),
                      RoundedButton(
                        text: 'LOGIN',
                        press: () {
                          PageRouter.loginPage(context);
                        },
                      ),
                      RoundedButton(
                        text: 'SIGN UP',
                        color: kPrimaryLightColor,
                        textColor: Colors.black,
                        press: () {
                          PageRouter.signupPage(context);
                        },
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

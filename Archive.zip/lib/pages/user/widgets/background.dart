import 'package:flutter/material.dart';

enum BackgroundType {
  welcome,
  login,
  signup,
}

class Background extends StatelessWidget {
  final Widget child;
  final BackgroundType type;

  const Background(
      {Key key, @required this.child, @required this.type})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final topImg = type == BackgroundType.signup
        ? 'assets/images/signup_top.png'
        : 'assets/images/main_top.png';
    final bottomImg = type == BackgroundType.login
        ? 'assets/images/login_bottom.png'
        : 'assets/images/main_bottom.png';

    return Container(
      width: 300,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Positioned(
            top: 0,
            left: 0,
            child: Image.asset(
              topImg,
              width: 80,
            ),
          ),
          Positioned(
            bottom: 0,
            left: 0,
            child: Image.asset(
              bottomImg,
              width: 80,
            ),
          ),
          child,
        ],
      ),
    );
  }
}

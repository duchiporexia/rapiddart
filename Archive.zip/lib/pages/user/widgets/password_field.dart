import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import '../../../common/form/form.dart';
import '../../../common/state.dart';

import '../model.dart';

class PasswordField extends StatelessWidget {
  PasswordField({
    Key key,
    this.isPwd2 = false,
    @required this.form,
  }) : super(key: key);

  final bool isPwd2;
  final XForm<User> form;
  final showPassword = XState<bool>(false);

  StringValidationCallback buildValidator() {
    final builder = ValidationBuilder()..minLength(3);
    builder.add((value) {
      if (form.state.password2 == null) {
        return null;
      }
      if (form.state.password != form.state.password2) {
        return 'Password doesn\'t match.';
      }
      return null;
    });
    return builder.build();
  }

  @override
  Widget build(BuildContext context) {
    return view((ctx) => TextFormField(
          onChanged: (v) {
            if (isPwd2) {
              form.state.password2 = v;
            } else {
              form.state.password = v;
            }
          },
          validator: isPwd2
              ? buildValidator()
              : ValidationBuilder().minLength(3).build(),
          obscureText: !showPassword.value,
          decoration: InputDecoration(
              hintText: isPwd2 ? 'Password Again' : 'Password',
              icon: Icon(
                Icons.lock,
                color: IconTheme.of(context).color,
              ),
              suffixIcon: GestureDetector(
                onTap: () {
                  showPassword.value = !showPassword.value;
                },
                child: MouseRegion(
                  cursor: SystemMouseCursors.click,
                  child: Icon(
                    showPassword.value ? Icons.visibility : Icons.visibility_off,
                  ),
                ),
              )),
        ));
  }
}

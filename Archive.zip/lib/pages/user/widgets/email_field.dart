import 'package:flutter/material.dart';
import '../../../common/form/form.dart';
import '../model.dart';

class EmailField extends StatelessWidget {
  const EmailField({
    Key key,
    @required this.form,
  }) : super(key: key);

  final XForm<User> form;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onChanged: (v) {
        form.state.email = v;
      },
      validator: ValidationBuilder().email().build(),
      decoration: InputDecoration(
          hintText: 'Email',
          icon: Icon(
            Icons.email,
            color: IconTheme.of(context).color,
          )),
    );
  }
}

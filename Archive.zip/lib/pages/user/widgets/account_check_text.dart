import 'package:flutter/material.dart';

class AccountCheckText extends StatelessWidget {
  final bool login;
  final GestureTapCallback press;

  const AccountCheckText({
    Key key,
    this.login = true,
    this.press,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(
          login ? 'Don\'t have an Account?' : 'Already have an Account?',
          style: TextStyle(color: primaryColor),
        ),
        Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: TextButton(
            onPressed: press,
            child: Text(
              login ? 'Sign Up' : 'Sign In',
              style: TextStyle(
                color: primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        )
      ],
    );
  }
}

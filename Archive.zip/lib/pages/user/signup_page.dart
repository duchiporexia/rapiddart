import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import '../../api/user.dart';
import 'widgets/background.dart';
import '../../router/page_router.dart';
import '../../common/form/form.dart';
import '../../common/state.dart';
import '../../widgets/button/rounded_button.dart';
import '../../constants/app_colors.dart';
import 'widgets/account_check_text.dart';
import 'widgets/email_field.dart';
import 'model.dart' as model;
import 'widgets/password_field.dart';

class SignupPage extends StatelessWidget {
  final form = XForm<model.User>(model.User(email: '', password: '', password2: ''));

  void onSubmit() {
    form.setState(() {
      form.autovalidateMode = AutovalidateMode.always;
      if (form.validate()) {
        form.save();
        print(form.state.email);
        print(form.state.password);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Background(
        type: BackgroundType.signup,
        child: form.child(SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'SIGNUP',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 30),
              SvgPicture.asset(
                'assets/icons/signup.svg',
                height: 200,
              ),
              EmailField(form: form),
              view((_) => PasswordField(form: form)),
              view((_) => PasswordField(form: form, isPwd2: true)),
              SizedBox(height: 20),
              RoundedButton(
                text: 'SIGNUP',
                press: onSubmit,
              ),
              SizedBox(height: 20),
              AccountCheckText(
                login: false,
                press: () {
                  PageRouter.loginPage(context);
                },
              ),
              OrDivider(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SocialIcon(
                    iconSrc: 'assets/icons/google-plus.svg',
                    press: () async {
                      // await loginOauth('google');
                      var googleProvider = GoogleAuthProvider();

                      googleProvider.addScope('https://www.googleapis.com/auth/userinfo.email');
                      googleProvider.addScope('https://www.googleapis.com/auth/userinfo.profile');

                      // Once signed in, return the UserCredential
                      var x = await FirebaseAuth.instance.signInWithPopup(googleProvider);
                      print(x.credential);
                      print(x.user);
                      print(x.additionalUserInfo);
                    },
                  ),
                  SocialIcon(
                    iconSrc: 'assets/icons/facebook.svg',
                    press: () {},
                  ),
                  SocialIcon(
                    iconSrc: 'assets/icons/twitter.svg',
                    press: () {},
                  ),
                ],
              )
            ],
          ),
        )),
      )),
    );
  }
}

class OrDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 30),
      child: Row(
        children: <Widget>[
          buildDivider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              'OR',
              style: TextStyle(
                color: kPrimaryColor,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          buildDivider(),
        ],
      ),
    );
  }

  Expanded buildDivider() {
    return Expanded(
      child: Divider(
        color: Color(0xFFD9D9D9),
        height: 1.5,
      ),
    );
  }
}

class SocialIcon extends StatelessWidget {
  final String iconSrc;
  final GestureTapCallback press;

  const SocialIcon({
    Key key,
    this.iconSrc,
    this.press,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: press,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 10),
        padding: EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(
            width: 2,
            color: kPrimaryLightColor,
          ),
          shape: BoxShape.circle,
        ),
        child: SvgPicture.asset(
          iconSrc,
          height: 20,
          width: 20,
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'widgets/password_field.dart';
import '../../common/common.dart';
import '../../common/form/form.dart';
import '../../router/page_router.dart';
import '../../widgets/button/rounded_button.dart';

import 'widgets/account_check_text.dart';
import 'widgets/background.dart';
import 'widgets/email_field.dart';
import 'model.dart';

class LoginPage extends StatelessWidget {
  final form = XForm<User>(User(email: '', password: ''));

  void onSubmit() {
    form.setState(() {
      form.autovalidateMode = AutovalidateMode.always;
      if (form.validate()) {
        form.save();
        print(form.state.email);
        print(form.state.password);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Background(
        type: BackgroundType.login,
        child: form.child(
          SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'LOGIN',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 30),
                SvgPicture.asset(
                  'assets/icons/login.svg',
                  height: 200,
                ),
                SizedBox(height: 30),
                EmailField(form: form),
                PasswordField(form: form),
                SizedBox(height: 20),
                RoundedButton(
                  text: 'LOGIN',
                  press: onSubmit,
                ),
                SizedBox(height: 30),
                AccountCheckText(
                  press: () async {
                    await PageRouter.signupPage(context);
                    form.reset();
                  },
                ),
              ],
            ),
          ),
        ),
      )),
    );
  }
}

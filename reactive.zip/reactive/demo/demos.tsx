import * as React from 'react';
import { create, state, stateV, link, ref, watch, stateLongArray, LongArrayItem, setDebugComponentName, wrapV, cache } from '../';

const delay = (ms: number) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
};

const gState = state({ count: 0, num: { v1: 0, v2: 100 } });

watch(
    (values, oldValues) => {
        // console.log('globally shared data changed:', JSON.stringify(values));
    },
    () => [gState.count, gState.num],
);

export const ReactiveDemo = create((ctx) => {
    console.log('App setup');
    setDebugComponentName('App');
    // watch(async (values, oldValues) => {
    //     console.log(`values:`, values, `oldValues:`, oldValues);
    //     // await delay(3000);
    //     // if (!ctx.active) {
    //     //     console.log('is inactive');
    //     //     return;
    //     // }
    //     // data.count++;
    //   }, () => [data.count, data.num]
    // );

    return () => {
        console.log('App render');
        return (
            <div>
                {/*<div>{JSON.stringify(data.num)}</div>*/}
                <ShowCountParent />
                <button
                    onClick={() => {
                        gState.count++;
                        gState.num.v1 += 1;
                        gState.num = wrapV(gState.num);
                        // data.num.v2 += 100;
                    }}>
                    +
                </button>
                <ShowNumField numV1={gState.num.v1} numV2={gState.num.v2} />
                <NestedParentComp />
                <ShowNum data={gState} />
                <ArrComp />
                <LongArrayComp />
                <DefaultPropsComp v1={2} />
                <CacheComp name={'cache comp'} val={gState.count} />
                <TestUpdateComp />
            </div>
        );
    };
});
// only render it once. so, it already takes advantage of react async batch rendering, which can combine multiple updates into one.
const TestUpdateComp = create(() => {
    console.log('TestUpdateComp setup');
    const data = stateV(100);
    return () => {
        console.log('TestUpdateComp render');
        return (
            <div>
                <button
                    onClick={() => {
                        Array.from({ length: 1000 }, (v, k) => k).forEach((v) => {
                            data.value += v;
                        });
                    }}>
                    add
                </button>
                {data.value}
            </div>
        );
    };
});

const CacheComp = cache<{ name: string; val: number }>(({ name, val }) => (
    <div>
        {name} name:{val}
    </div>
));

const ShowNumField = create<{ numV1: number; numV2: number }>((ctx) => {
    console.log(`ShowNumField setup: ${ctx.props.numV1} ${ctx.props.numV2}`);
    setDebugComponentName('ShowNumField');

    const watcher = watch(
        async () => {
            if (ctx.props.numV1 > 3) {
                console.log('unwatch');
                watcher.unwatch();
                return;
            }
            console.log(`ShowNumField watch start: ${ctx.props.numV1}  ${ctx.props.numV2}...`);
            await delay(2000);
            console.log(`ShowNumField watch done: ${ctx.active} ${watcher.active}: ${ctx.props.numV1}  ${ctx.props.numV2}`);
        },
        () => [ctx.w().numV1],
    );

    // unwatch(watcher);

    ctx.onDispose(() => {
        console.log(`ShowNumField teardown: ${ctx.props.numV1}  ${ctx.props.numV2} `);
    });
    return (props) => {
        console.log(`ShowNumField render: ${props.numV1}  ${props.numV2} `);
        return (
            <div>
                ShowNumField: {props.numV1} {props.numV2}
            </div>
        );
    };
});

const ShowNum = create<{ data: { num: { v1: number; v2: number } } }>((ctx) => {
    console.log('ShowNum: setup');
    setDebugComponentName('ShowNum');

    return (props) => {
        console.log('ShowNum render');
        return <div>ShowNum:{JSON.stringify(props.data.num)}</div>;
    };
});

const ShowCountParent = create(() => {
    console.log('ShowCountParent setup');
    setDebugComponentName('ShowCountParent');

    return () => {
        console.log('ShowCountParent: render');
        return (
            <>
                <div>good</div>
                <ShowCount name={'ShowCount'} />
            </>
        );
    };
});

const ShowCount = create<{ name: string }>((ctx) => {
    console.log('ShowCount setup');
    setDebugComponentName('ShowCount');

    return (props) => {
        const { count } = gState;
        console.log('ShowCount: render');
        return (
            <div>
                {props.name}: {count}
                <ShowCountChild name={'ShowCountChild'} count={null} />
                <ShowCountLinkChild />
                <ShowCountStateVChild name={'ShowCountStateVChild'} />
            </div>
        );
    };
});

const ShowCountStateVChild = create<{ name: string }>(() => {
    console.log('ShowCountStateVChild setup');
    setDebugComponentName('ShowCountStateVChild');

    const one = stateV(100);
    const two = stateV(200);
    const third = state({ val: 300 });

    const plusOne = () => {
        one.value++;
    };
    watch(
        () => {
            console.log('one:', one.value);
        },
        () => [one.value],
    );

    return (props) => {
        console.log('ShowCountStateVChild render');
        return (
            <div>
                <span>{props.name}</span>&nbsp;&nbsp;
                <span>{one.value}</span> &nbsp;&nbsp;
                <span>{two.value}</span>&nbsp;&nbsp;
                <span>{third.val}</span>&nbsp;&nbsp;
                <button onClick={plusOne}>add</button>
            </div>
        );
    };
});

const ShowCountChild = create<{ name: string; count: number }>(() => {
    console.log('ShowCountChild setup');
    setDebugComponentName('ShowCountChild');

    return (props) => {
        console.log('ShowCountChild render');
        return (
            <>
                <div>
                    name:{props.name} {props.count}
                </div>
            </>
        );
    };
});

const ShowCountLinkChild = create(() => {
    console.log('ShowCountLinkChild setup');
    setDebugComponentName('ShowCountLinkChild');

    const doubleCount = link(() => gState.count * 2);
    const doublePlusCount = link(
        () => doubleCount.value + 1000,
        (newValue) => {
            gState.count = newValue;
        },
    );
    return (props) => {
        console.log('ShowCountLinkChild render');
        return (
            <>
                <div>
                    ShowCountLinkChild: count:{gState.count} doublePlusCount:
                    {doublePlusCount.value}
                </div>
                <button
                    onClick={() => {
                        const v = doublePlusCount.value;
                        doublePlusCount.value = v;
                    }}>
                    linkAdd
                </button>
            </>
        );
    };
});

const NestedParentComp = create(() => {
    console.log('NestedParentComp setup');
    setDebugComponentName('NestedParentComp');

    const ps = state({ v: 10 });
    const NestedChildComp = create(() => {
        console.log('NestedChildComp setup');
        const cs = state({ v: 100 });

        return () => {
            console.log('NestedChildComp render');
            return (
                <>
                    <div>{cs.v} </div>
                    <button
                        onClick={() => {
                            cs.v++;
                            gState.count++;
                        }}>
                        add
                    </button>
                </>
            );
        };
    });

    return () => {
        console.log('NestedParentComp render');
        return (
            <>
                <NestedChildComp />
                <div>{ps.v}</div>
                <button onClick={() => ps.v++}>add</button>
            </>
        );
    };
});

const ArrComp = create(() => {
    console.log('ArrComp setup');
    setDebugComponentName('ArrComp');

    let gKey = 100;
    const arr = stateV([]);
    const ItemComp = create<{ item: number }>((ctx) => {
        console.log(`ItemComp ${ctx.props.item} setup`);
        setDebugComponentName('ItemComp');

        return (props) => {
            console.log(`ItemComp ${props.item} render`);
            return <span>{props.item}&nbsp;</span>;
        };
    });

    return () => {
        console.log('ArrComp render');
        return (
            <>
                <br />
                ArrComp &nbsp;
                <button
                    onClick={() => {
                        arr.value.push(gKey++);
                        arr.value = [...arr.value];
                    }}>
                    add to arr
                </button>
                <button
                    onClick={() => {
                        arr.value.pop();
                        arr.value = [...arr.value];
                    }}>
                    delete from arr
                </button>
                <button
                    onClick={() => {
                        gKey += 100;
                        arr.value[1] = gKey;
                        arr.value = [...arr.value];
                        gKey += 1;
                    }}>
                    change second item
                </button>
                <button
                    onClick={() => {
                        arr.value = [];
                    }}>
                    reset
                </button>
                <br />
                {arr.value.map((v, idx) => (
                    <ItemComp key={idx} item={v} />
                ))}
            </>
        );
    };
});

const LongArrayComp = create(() => {
    console.log('LongArrayComp setup');
    setDebugComponentName('LongArrayComp');

    let gKey = 100;

    const arr = stateLongArray([]);
    // Optimized
    const arrLink = link(() => arr.filterItems((item) => item.value !== 1002));
    // Optimized
    const itemValuesRef = ref(() => arr.values);

    const LongArrayItemComp = create<{ item: LongArrayItem<number> }>((ctx) => {
        const itemValue = ctx.props.item.value;
        console.log(`LongArrayItemComp ${itemValue} setup`);
        setDebugComponentName('LongArrayItemComp');

        ctx.onDispose(() => {
            console.log(`LongArrayItemComp ${itemValue} teardown`);
        });

        return (props) => {
            console.log(`LongArrayItemComp ${props.item.value} render`);
            return <span>{props.item.value}&nbsp;</span>;
        };
    });

    return () => {
        // console.log('LongArrayComp render', JSON.stringify(arr.value));
        console.log('LongArrayComp render');
        return (
            <>
                <br />
                LongArrayComp &nbsp;
                <button onClick={() => arr.push(gKey++)}>add to arr</button>
                <button onClick={() => arr.pop()}>delete from arr</button>
                <button
                    onClick={() => {
                        gKey += 100;
                        arr.set(1, gKey);
                        gKey += 1;
                    }}>
                    change second item
                </button>
                <button onClick={() => (arr.values = [])}>reset</button>
                <button onClick={() => arr.add(2, gKey++, gKey++)}>add two at index 2</button>
                <button onClick={() => arr.remove(1, 2)}>remove two at index 1</button>
                <br />
                {arrLink.value.mapItems((item, idx) => (
                    // Optimized: link/ref should be faster than idx when adding or removing items from the beginning. because no direct view dependency on item.value.
                    <LongArrayItemComp key={itemValuesRef.value[idx]} item={item} />
                ))}
            </>
        );
    };
});

const DefaultPropsComp = create<{ v1: number; v2?: number }>((ctx) => {
    const compName = 'DefaultPropsComp';
    console.log(`${compName} setup: ${ctx.props.v1} ${ctx.props.v2}`);
    setDebugComponentName(compName);
    ctx.defaultProps = {
        v2: 1003,
    };
    return (props) => {
        console.log(`${compName} render`);
        return (
            <div>
                {compName}:{props.v1} {props.v2}
            </div>
        );
    };
});

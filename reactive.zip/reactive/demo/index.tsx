import * as React from 'react';
import { ReactiveDemo } from './demos';
import { render } from 'react-dom';

// @ts-ignore
render(<ReactiveDemo />, document.getElementById('root'));

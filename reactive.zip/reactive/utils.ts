import * as React from 'react';
import { getEffect, unwatch, state, Effect, track, trigger } from './reactive';
import { Context, StateV } from './model';

let currSysCtx: SysContext<any>;

export function create<T>(
    setup: (ctx: Context<T>) => (props: T) => React.ReactNode,
): React.FC<T> {
    //////////////////////////////////////////////////
    const dom = React.memo((_props: T) => {
        const update = React.useReducer((s) => s + 1, 0)[1];
        const sysCtxRef = React.useRef<SysContext<T>>({
            effect: null,
            cleanup: new Set<() => void>(),
            props: _props,
            watchProps: state({ v: _props }),
        });
        const sysCtx = sysCtxRef.current;
        React.useEffect(() => {
            return () => {
                sysCtx.cleanup.forEach((c) => c());
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
        ////////////////////////////////////////////////
        sysCtx.props = _props;
        sysCtx.watchProps.v = _props;
        let effect = sysCtx.effect;
        if (!effect) {
            currSysCtx = sysCtx;
            const ctx = new _Context(sysCtx);
            const render = setup(ctx);
            const getter = () => render(sysCtx.props);
            effect = getEffect(getter, () => update());
            sysCtx.cleanup.add(() => unwatch(effect));
            sysCtx.effect = effect;
        }
        return effect();
    });
    return dom as any;
}

export function watch(
    cb: (values, oldValues) => void | Promise<void>,
    deps?: () => any[],
) {
    let oldValues = null;
    const update = () => {
        if (!effect.active) {
            return;
        }
        const values = effect();
        cb(values, oldValues);
        oldValues = values;
    };
    const getter = deps ?? (() => null);

    const effect = getEffect(getter, update);
    currSysCtx.cleanup.add(() => unwatch(effect));

    const values = effect();
    cb(values, oldValues);
    oldValues = values;

    return effect;
}

export function link<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    const linkId = {};
    let value: T;

    const update = (newValues: T[]) => {
        if (value !== newValues[0]) {
            value = newValues[0];
            trigger({
                target: linkId,
                key: '_',
                type: 'set',
            });
        }
    };

    const effect = watch(update, () => [getter()]);

    return {
        effect,
        get value() {
            track({ target: linkId, key: '_', type: 'get' });
            return value;
        },
        set value(newValue: T) {
            if (effect.active && setter != null) {
                setter(newValue);
            }
        },
    } as any;
}

// tslint:disable-next-line:class-name
class _Context<T> {
    _sysCtx: SysContext<T>;

    constructor(sysCtx: SysContext<T>) {
        this._sysCtx = sysCtx;
    }

    get active(): boolean {
        return this._sysCtx.effect.active ?? false;
    }
    get props(): T {
        return this._sysCtx.props;
    }
    w(): T {
        return this._sysCtx.watchProps.v;
    }
    onDispose(cb: () => void) {
        if (!this._sysCtx.cleanup.has(cb)) {
            this._sysCtx.cleanup.add(cb);
        }
    }
}

interface SysContext<T> {
    cleanup: Set<() => void>;
    effect: Effect;
    props: T;
    watchProps: { v: T };
}

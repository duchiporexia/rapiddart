import { StateV } from './model';
import { getProxy } from './proxy';

type KeyEffectSet = Map<Key, Set<Effect>>;
type Key = string | number;
type Raw = object;
type Proxy = object;

// @ts-ignore
// eslint-disable-next-line no-new-func
const g = typeof window === 'object' ? window : Function('return this')();
const targetMap = new WeakMap<Raw, KeyEffectSet>();
const proxyToRaw = new WeakMap<Proxy, Raw>();
const rawToProxy = new WeakMap<Raw, Proxy>();
export let currEffect = null;
const SET = 'set';
const GET = 'get';

let gEffectId = 0;

export function getEffect<T>(fn: () => T, scheduler: () => void): Effect {
    const effect: Effect = function () {
        // @ts-ignore
        return run(effect, fn, this, arguments);
    };
    effect.active = true;
    effect.scheduler = scheduler;
    effect.id = gEffectId++;
    return effect;
}

function run<T>(effect: Effect, fn: () => T, ctx, args): T {
    if (!effect.active) {
        return Reflect.apply(fn, ctx, args);
    }
    cleanup(effect);
    const oldEffect = currEffect;
    currEffect = effect;
    // console.log(`set effect:${oldEffect?.id} to ${effect?.id}`);
    const ret = Reflect.apply(fn, ctx, args);
    // console.log(`reset effect:${currEffect?.id} to ${oldEffect?.id}`);
    currEffect = oldEffect;
    return ret;
}

export function unwatch(effect: Effect): void {
    if (effect.active) {
        cleanup(effect);
        effect.active = false;
    }
}

function cleanup(effect: Effect): void {
    if (effect.deps) {
        effect.deps.forEach((deps: Set<Effect>) => deps.delete(effect));
    }
    effect.deps = [];
}

function buildIn({ constructor }: Raw) {
    return (
        isFn(constructor) &&
        constructor.name in g &&
        g[constructor.name] === constructor
    );
}

export function stateV<T>(value?: T): StateV<T> {
    return state({ value });
}

export function state<T extends Raw>(raw: T): T {
    if (proxyToRaw.has(raw) || !buildIn(raw)) {
        return raw;
    }
    const proxy = rawToProxy.get(raw);
    if (proxy) {
        return proxy as T;
    }
    const reactive = getProxy(raw, handlers);

    rawToProxy.set(raw, reactive);
    proxyToRaw.set(reactive, raw);
    targetMap.set(raw, new Map() as KeyEffectSet);

    return reactive as T;
}

const handlers = {
    get(target: Raw, key: Key) {
        const result = Reflect.get(target, key);
        track({ target, key, type: GET });
        const proxy = rawToProxy.get(result);
        if (isObj(result)) {
            if (proxy) {
                return proxy;
            }
            // only watch the root fields of object
            // return state(result);
            return result;
        }
        return proxy || result;
    },
    set(target: Raw, key: Key, value: any) {
        if (isObj(value)) {
            value = proxyToRaw.get(value) ?? value;
        }
        const oldValue = target[key];
        if (value === oldValue) {
            return true;
        }
        const result = Reflect.set(target, key, value);
        trigger({ target, key, type: SET });
        return result;
    },
};

export function track(operation: Operation) {
    // console.log(`track effect:${currEffect?.id},key:${operation.key?.toString()}, target:${JSON.stringify(operation.target)}`);
    const effect: Effect = currEffect;
    if (effect) {
        const { key, type, target } = operation;
        let depsMap = targetMap.get(target);
        if (!depsMap) {
            targetMap.set(target, (depsMap = new Map()));
        }
        let deps = depsMap.get(key);
        if (!deps) {
            depsMap.set(key, (deps = new Set()));
        }
        if (!deps.has(effect)) {
            // console.log(`effect:${effect.id}, key:${key?.toString()}`);
            deps.add(effect);
            effect.deps.push(deps);
        }
    }
}

export function trigger(operation: Operation) {
    const { target, key } = operation;
    const deps = targetMap.get(target);
    const effects = new Set();
    addTo(effects, deps, key);
    effects.forEach((e: Effect) => {
        isFn(e.scheduler) ? e.scheduler(e) : e();
    });
}

function addTo(effects, deps, key) {
    const dep = deps?.get(key);
    dep && dep.forEach((e) => effects.add(e));
}

export const isObj = (x: any): boolean => typeof x === 'object';
export const isFn = (x: any): boolean => typeof x === 'function';

// tslint:disable-next-line:ban-types
export type Effect = Function & {
    active?: boolean;
    scheduler?: (e: Effect) => void;
    deps?: Array<Set<Effect>>;
    id: number;
};

interface Operation {
    type: 'get' | 'iterate' | 'add' | 'set' | 'delete' | 'clear' | 'has';
    target: object;
    key?: Key;
}

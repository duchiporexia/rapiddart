import { create, watch, link, softLink, ref, wrapV } from './func';
import { unwatch, state, stateV, setDebugGEffectName } from './core';
import { StateV, Context } from './model';
import { stateLongArray, LongArray, LongArrayItem } from './long_array';

export { state, stateV, stateLongArray, create, link, softLink, ref, watch, unwatch, wrapV };
export type { StateV, Context, LongArray, LongArrayItem };
export { setDebugGEffectName };

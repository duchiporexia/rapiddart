type RequiredKeys<T> = { [K in keyof T]-?: {} extends Pick<T, K> ? never : K }[keyof T];
type OptionalKeys<T> = { [K in keyof T]-?: {} extends Pick<T, K> ? K : never }[keyof T];

export type DefaultProps<T> = Pick<T, OptionalKeys<T>>;

export const notEqual = (a, b) => {
    if (!a) {
        return true;
    }
    return a.some((arg, index) => arg !== b[index]);
};

export const isObj = (x: any): boolean => typeof x === 'object';
export const isFn = (x: any): boolean => typeof x === 'function';

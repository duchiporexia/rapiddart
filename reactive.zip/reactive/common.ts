type RequiredKeys<T> = { [K in keyof T]-?: {} extends Pick<T, K> ? never : K }[keyof T];
type OptionalKeys<T> = { [K in keyof T]-?: {} extends Pick<T, K> ? K : never }[keyof T];

export type DefaultProps<T> = Pick<T, OptionalKeys<T>>;

export const notEqual = (a, b) => !a || b.some((arg, index) => arg !== a[index]);

export const isObj = (x: any): boolean => typeof x === 'object';
export const isFn = (x: any): boolean => typeof x === 'function';

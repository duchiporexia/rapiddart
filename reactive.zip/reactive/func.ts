import * as React from 'react';
import { getEffect, unwatch, state, Effect, track, trigger } from './core';
import { Context, StateV } from './model';

let currSysCtx: SysContext<any>;
// setup:
//  -- only be called once at the beginning of the whole lifecycle of the component.
//  -- Create same states, or use watch/link functions or create any user defined functions or any normal (non-reactive) variables.
//  -- return a render function, which can be used for rendering the components many times.
export function create<T extends object>(setup: (ctx: Context<T>) => (props: T) => React.ReactNode): React.FC<T> {
    //////////////////////////////////////////////////
    const dom = React.memo((_props: T) => {
        const update = React.useReducer((s) => s + 1, 0)[1];
        const sysCtxRef = React.useRef<SysContext<T>>({
            effect: null,
            cleanup: new Set<() => void>(),
            props: _props,
            watchProps: state<T>({ ..._props }),
        });
        const sysCtx = sysCtxRef.current;
        React.useEffect(() => {
            return () => {
                sysCtx.cleanup.forEach((c) => c());
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
        ////////////////////////////////////////////////
        if (_props !== sysCtx.props) {
            sysCtx.props = _props;
            Object.keys(_props).forEach((k) => {
                sysCtx.watchProps[k] = _props[k];
            });
        }
        let effect = sysCtx.effect;
        if (!effect) {
            currSysCtx = sysCtx;
            const ctx = new _Context(sysCtx);
            const render = setup(ctx);
            const getter = () => render(sysCtx.props);
            effect = getEffect(getter, update);
            sysCtx.cleanup.add(() => unwatch(effect));
            sysCtx.effect = effect;
        }
        return effect();
    });
    return dom as any;
}
// watch the deps function.
// -- call cb function once when any 'state*' values in the deps function gets updated.
export function watch(cb: (values, oldValues) => void | Promise<void>, deps?: () => any[]) {
    let oldValues = null;
    const update = () => {
        if (!effect.active) {
            return;
        }
        const values = effect();
        cb(values, oldValues);
        oldValues = values;
    };
    const getter = deps ?? (() => null);

    const effect = getEffect(getter, update);
    currSysCtx?.cleanup.add(() => unwatch(effect));

    const values = effect();
    cb(values, oldValues);
    oldValues = values;

    return effect;
}
// link is a pair of getter and setter function, just for convenience.
// -- use `linkVar.value` or `linkVar.value = otherValue`
export function link<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, setter);
}
// use softLink to break the direct dependency between state (item.value) and view, there is still a dependency between link and view.
export function softLink<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, setter, 'soft');
}
// use ref to break all dependencies between state (item.value) and view.
export function ref<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, undefined, 'ref');
}

// linkWithOptions is a pair of getter and setter function.
function linkWithOptions<T>(getter: () => T, setter?: (v: T) => void, option?: 'soft' | 'ref'): StateV<T> {
    const linkId = {};
    let value: T;

    const update = (newValues: T[]) => {
        const oldValue = value;
        value = newValues[0];
        let needTrigger = true;
        if (option === 'soft' && value === oldValue) {
            needTrigger = false;
        } else if (option === 'ref') {
            needTrigger = false;
        }
        if (needTrigger) {
            trigger({
                target: linkId,
                key: '_',
                type: 'set',
            });
        }
    };

    const effect = watch(update, () => [getter()]);

    return {
        effect,
        get value() {
            if (option !== 'ref') {
                track({ target: linkId, key: '_', type: 'get' });
            }
            return value;
        },
        set value(newValue: T) {
            if (effect.active && setter != null) {
                setter(newValue);
            }
        },
    } as any;
}

export const wrapV = (v) => v;

// Context can be used in any functions within the setup function.
// tslint:disable-next-line:class-name
class _Context<T> {
    _sysCtx: SysContext<T>;

    constructor(sysCtx: SysContext<T>) {
        this._sysCtx = sysCtx;
    }

    // if the component is unmounted, its active is false.
    get active(): boolean {
        return this._sysCtx.effect.active ?? false;
    }
    // latest Prop values.
    get props(): T {
        return this._sysCtx.props;
    }
    // can be used to watch any changes of any prop in `watch` function.
    // like: ctx.w().prop1
    w(): T {
        return this._sysCtx.watchProps;
    }
    // will be called when the component is about to be unmounted.
    onDispose(cb: () => void) {
        if (!this._sysCtx.cleanup.has(cb)) {
            this._sysCtx.cleanup.add(cb);
        }
    }
}

interface SysContext<T> {
    cleanup: Set<() => void>;
    effect: Effect;
    props: T;
    watchProps: T;
}

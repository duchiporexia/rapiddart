import * as React from 'react';
import { track, trigger, stateV, Executor } from './core';
import { Context, StateV, Watcher } from './model';
import { DefaultProps, notEqual } from './common';
import { memo } from 'react';

let currSysCtx: SysContext<any>;
// setup:
//  -- only be called once at the beginning of the whole lifecycle of the component.
//  -- Create same states, or use watch/link functions or create any user defined functions or any normal (non-reactive) variables.
//  -- return a render function, which can be used for rendering the components many times.
export function create<T extends object>(setup: (ctx: Context<T>) => (props: T) => React.ReactNode): React.FC<T> {
    //////////////////////////////////////////////////
    const dom = React.memo((_props: T) => {
        const update = React.useReducer((s) => s + 1, 0)[1];
        const sysCtxRef = React.useRef<SysContext<T>>({
            executor: null,
            cleanup: new Set<() => void>(),
            props: _props,
            defaultProps: null,
            watchProps: stateV<T>(_props),
        });
        const sysCtx = sysCtxRef.current;
        React.useEffect(() => {
            return () => {
                sysCtx.cleanup.forEach((c) => c());
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
        ////////////////////////////////////////////////
        if (_props !== sysCtx.props) {
            sysCtx.props = _props;
            sysCtx.watchProps.value = _props;
        }
        let executor = sysCtx.executor;
        if (!executor) {
            currSysCtx = sysCtx;
            const ctx = new _Context(sysCtx);
            const render = setup(ctx);
            executor = new Executor(() => render(ctx.props), update);
            sysCtx.cleanup.add(() => executor.unwatch());
            sysCtx.executor = executor;
        }
        return executor.getter();
    });
    return dom as any;
}
// only rerender when any props has changed. (non-reactive)
export { memo as cache };

// -- deep: update the link value, and update its parent(most of the time, the view) as long as any state* changes in the deps function.
export function deepLink<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, setter, 'deep');
}
// -- update the link value, and update its parent when the value changes.
export function link<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, setter, null);
}
// use ref to break all dependencies between state (item.value) and view.
// -- ref: just update the link value, don't update its parent.
export function ref<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    return linkWithOptions(getter, undefined, 'ref');
}

// linkWithOptions is a pair of getter and setter function.
function linkWithOptions<T>(getter: () => T, setter: (v: T) => void, option: 'deep' | 'ref' | null): StateV<T> {
    const linkId = {};
    let value: T;

    const update = (newValues: T) => {
        value = newValues[0];
        if (option === 'ref') {
            return;
        }
        trigger({
            target: linkId,
            key: '_',
            type: 'set',
        });
    };

    let watchOption = null;
    if (option === 'deep') {
        watchOption = 'deep';
    }

    const watcher = watchWithOption(update, () => [getter()], watchOption);

    return {
        watcher, // just for debug.
        get value() {
            if (option !== 'ref') {
                track({ target: linkId, key: '_', type: 'get' });
            }
            return value;
        },
        set value(newValue: T) {
            if (watcher.active && setter != null) {
                setter(newValue);
            }
        },
    } as any;
}

// watch the deps function.
// -- call cb function once when any 'state*' values in the deps function gets updated and the deps value list is not the same as before.
export function watch(cb: (values, oldValues) => void | Promise<void>, deps?: () => any[]) {
    return watchWithOption(cb, deps, null);
}
// watch the deps function.
// -- call cb function once when any 'state*' values in the deps function gets updated.
export function deepWatch(cb: (values, oldValues) => void | Promise<void>, deps?: () => any[]) {
    return watchWithOption(cb, deps, 'deep');
}

export function watchWithOption(cb: (values, oldValues) => void | Promise<void>, deps: () => any[], option: 'deep' | null): Watcher {
    let oldValues = null;
    const update = () => {
        if (!executor.active) {
            return;
        }
        const values = executor.getter();
        let needCall = true;
        if (option == null) {
            needCall = notEqual(values, oldValues);
        }
        if (needCall) {
            cb(values, oldValues);
        }
        oldValues = values;
    };
    const getter = deps ?? (() => null);

    const executor = new Executor(getter, update);
    currSysCtx?.cleanup.add(() => executor.unwatch());

    const values = executor.getter();
    cb(values, oldValues);
    oldValues = values;

    return executor;
}

// wrap a value, commonly used for triggering view updates depending on the value.
export const wrapV = (v) => v;

// Context can be used in any functions within the setup function.
// tslint:disable-next-line:class-name
class _Context<T> {
    _sysCtx: SysContext<T>;

    constructor(sysCtx: SysContext<T>) {
        this._sysCtx = sysCtx;
    }

    // if the component is unmounted, its active is false.
    get active(): boolean {
        return this._sysCtx.executor.active ?? false;
    }
    // latest Prop values with defaultProps.
    get props(): T {
        if (this._sysCtx.defaultProps != null) {
            return { ...this._sysCtx.defaultProps, ...this._sysCtx.props };
        }
        return this._sysCtx.props;
    }

    set defaultProps(value: DefaultProps<T>) {
        this._sysCtx.defaultProps = value;
    }
    // can be used to watch any changes of any prop in `watch` function.
    // like: ctx.w().prop1
    w(): T {
        return this._sysCtx.watchProps.value;
    }
    // will be called when the component is about to be unmounted.
    onDispose(cb: () => void) {
        if (!this._sysCtx.cleanup.has(cb)) {
            this._sysCtx.cleanup.add(cb);
        }
    }
}

interface SysContext<T> {
    cleanup: Set<() => void>;
    executor: Executor;
    props: T;
    defaultProps: DefaultProps<T>;
    watchProps: StateV<T>;
}

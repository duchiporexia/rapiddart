import * as React from 'react';
import { getEffect, unwatch, state, Effect, track, trigger } from './reactive';
import { Context, StateV } from './model';

let currSysCtx: SysContext<any>;
// setup:
//  -- just be called once.
//  -- Create same states, or use watch/link functions or create user defined functions.
//  -- return a render function, which can be used for rendering the components many times.
export function create<T extends object>(setup: (ctx: Context<T>) => (props: T) => React.ReactNode): React.FC<T> {
    //////////////////////////////////////////////////
    const dom = React.memo((_props: T) => {
        const update = React.useReducer((s) => s + 1, 0)[1];
        const sysCtxRef = React.useRef<SysContext<T>>({
            effect: null,
            cleanup: new Set<() => void>(),
            props: _props,
            watchProps: state<T>({ ..._props }),
        });
        const sysCtx = sysCtxRef.current;
        React.useEffect(() => {
            return () => {
                sysCtx.cleanup.forEach((c) => c());
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []);
        ////////////////////////////////////////////////
        if (_props !== sysCtx.props) {
            sysCtx.props = _props;
            Object.keys(_props).forEach((k) => {
                sysCtx.watchProps[k] = _props[k];
            });
        }
        let effect = sysCtx.effect;
        if (!effect) {
            currSysCtx = sysCtx;
            const ctx = new _Context(sysCtx);
            const render = setup(ctx);
            const getter = () => render(sysCtx.props);
            effect = getEffect(getter, update);
            sysCtx.cleanup.add(() => unwatch(effect));
            sysCtx.effect = effect;
        }
        return effect();
    });
    return dom as any;
}
// watch the deps function.
// -- call cb function once when any 'state*' values in the deps function gets updated.
export function watch(cb: (values, oldValues) => void | Promise<void>, deps?: () => any[]) {
    let oldValues = null;
    const update = () => {
        if (!effect.active) {
            return;
        }
        const values = effect();
        cb(values, oldValues);
        oldValues = values;
    };
    const getter = deps ?? (() => null);

    const effect = getEffect(getter, update);
    currSysCtx.cleanup.add(() => unwatch(effect));

    const values = effect();
    cb(values, oldValues);
    oldValues = values;

    return effect;
}
// link can a pair of getter and setter function.
// -- can be used as a cache value of the getter function.
// -- link is just shallow comparison. So, if the value is the same object, it will not update for the view.
// -- can be used to break the dependency between state* and view. (because if the view uses the state* directly, when the state gets updated, the view will be updated, which, sometimes, is not efficient.)
export function link<T>(getter: () => T, setter?: (v: T) => void): StateV<T> {
    const linkId = {};
    let value: T;

    const update = (newValues: T[]) => {
        if (value !== newValues[0]) {
            value = newValues[0];
            trigger({
                target: linkId,
                key: '_',
                type: 'set',
            });
        }
    };

    const effect = watch(update, () => [getter()]);

    return {
        effect,
        get value() {
            track({ target: linkId, key: '_', type: 'get' });
            return value;
        },
        set value(newValue: T) {
            if (effect.active && setter != null) {
                setter(newValue);
            }
        },
    } as any;
}

// Context can be used in any functions in the setup function
// tslint:disable-next-line:class-name
class _Context<T> {
    _sysCtx: SysContext<T>;

    constructor(sysCtx: SysContext<T>) {
        this._sysCtx = sysCtx;
    }

    // if the component is unmounted, its active is false.
    get active(): boolean {
        return this._sysCtx.effect.active ?? false;
    }
    // latest props
    get props(): T {
        return this._sysCtx.props;
    }
    // can be used for watching the changes of props in `watch` function.
    w(): T {
        return this._sysCtx.watchProps;
    }
    // will be called when the component is about to be unmounted.
    onDispose(cb: () => void) {
        if (!this._sysCtx.cleanup.has(cb)) {
            this._sysCtx.cleanup.add(cb);
        }
    }
}

interface SysContext<T> {
    cleanup: Set<() => void>;
    effect: Effect;
    props: T;
    watchProps: T;
}
